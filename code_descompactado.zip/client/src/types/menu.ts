export type ProductId = "classico" | "casadinho" | "cacau" | "jucara";

export type MenuProduct = {
  id: ProductId;
  name: string;
  description: string;
  badge: string;
  icon: string;
  prices: readonly number[];
  traditional?: boolean;
};

export type MenuSize = {
  label: string;
  short: string;
  calories: number;
};

export type MenuTopping = {
  name: string;
  price: number;
};

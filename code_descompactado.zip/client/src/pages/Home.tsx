import { flushSync } from "react-dom";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Check, Leaf, Minus, Plus, Waves, X } from "lucide-react";
import Cup3DViewer from "@/components/Cup3DViewer";
import { DemoLoginCard, SplashScreen, isValidName, normalizeName } from "@/components/EntryScreens";
import ProductCupIllustration from "@/components/ProductCupIllustration";
import { SurrealAcaiScene } from "@/components/SurrealAcaiScene";
import type { MenuProduct, MenuSize, MenuTopping } from "@/types/menu";

const greetingStorageKey = "mare-roxa:visitor-name";
function readSavedName() {
  try {
    const saved = window.localStorage.getItem(greetingStorageKey);
    if (!saved) return "";
    if (!isValidName(saved)) {
      window.localStorage.removeItem(greetingStorageKey);
      return "";
    }
    const normalized = normalizeName(saved);
    if (!isValidName(normalized)) {
      window.localStorage.removeItem(greetingStorageKey);
      return "";
    }
    if (normalized !== saved) window.localStorage.setItem(greetingStorageKey, normalized);
    return normalized;
  } catch {
    return "";
  }
}

const sizes: readonly MenuSize[] = [
  { label: "300 ml", short: "P", calories: 210 },
  { label: "500 ml", short: "M", calories: 350 },
  { label: "700 ml", short: "G", calories: 490 },
  { label: "1 litro", short: "GG", calories: 720 },
];
const products: readonly MenuProduct[] = [
  { id: "classico", name: "Clássico da Ilha", description: "Açaí cremoso, banana e granola da casa.", badge: "O queridinho", icon: "✳", prices: [17, 25, 31, 40] },
  { id: "casadinho", name: "Casadinho da Maré", description: "Metade açaí, metade creme de cupuaçu.", badge: "Dois mundos", icon: "◒", prices: [19, 27, 34, 43] },
  { id: "cacau", name: "Açaí & Cacau", description: "Açaí intenso, nibs de cacau e melado.", badge: "Sem pressa", icon: "✺", prices: [20, 28, 36, 45] },
  { id: "jucara", name: "Juçara da Ilha", description: "No jeito da ilha: farinha d’água e camarão seco.", badge: "Sabor de casa", icon: "〰", prices: [20, 29, 38, 50], traditional: true },
];
const toppings: readonly MenuTopping[] = [
  { name: "Granola da casa", price: 0 },
  { name: "Banana em rodelas", price: 0 },
  { name: "Farinha d’água", price: 0 },
  { name: "Leite em pó", price: 0 },
  { name: "Coco tostado", price: 2 },
  { name: "Paçoca de amendoim", price: 3 },
  { name: "Creme de cupuaçu", price: 5 },
  { name: "Camarão seco", price: 6 },
];
const brl = (value: number) => value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
type EntryStage = "splash" | "login" | "site";
type ViewTransitionDocument = Document & { startViewTransition?: (update: () => void) => { finished: Promise<void> } };

export default function Home() {
  const [storedName] = useState(readSavedName);
  const [stage, setStage] = useState<EntryStage>("splash");
  const [greeting, setGreeting] = useState("");
  const [dissolving, setDissolving] = useState(false);
  const [selected, setSelected] = useState<MenuProduct | null>(null);
  const [sizeIndex, setSizeIndex] = useState(1);
  const [selectedToppings, setSelectedToppings] = useState<Record<string, number>>({});
  const [showCalories, setShowCalories] = useState(false);
  const dialogRef = useRef<HTMLDialogElement>(null);
  const carouselRef = useRef<HTMLDivElement>(null);
  const returnFocusRef = useRef<HTMLButtonElement | null>(null);
  const entryTimerRef = useRef<number | null>(null);
  const viewerActiveRef = useRef(false);
  const splashFinishedRef = useRef(false);

  const total = useMemo(() => {
    if (!selected) return 0;
    const extra = Object.entries(selectedToppings).reduce((sum, [name, quantity]) => sum + quantity * (toppings.find((item) => item.name === name)?.price ?? 0), 0);
    return selected.prices[sizeIndex] + extra;
  }, [selected, selectedToppings, sizeIndex]);
  const toppingsMessage = Object.entries(selectedToppings)
    .filter(([, quantity]) => quantity > 0)
    .map(([name, quantity]) => quantity > 1 ? `${name} (${quantity}x)` : name)
    .join(", ");
  const orderMessage = selected
    ? `Oi! Quero pedir: ${selected.name} (${sizes[sizeIndex].label})${toppingsMessage ? `, com ${toppingsMessage}` : ""}. Total ilustrativo: ${brl(total)}. Vi no site demonstrativo da Maré Roxa.`
    : "Oi! Vim pelo site demonstrativo da Maré Roxa e gostaria de conhecer o cardápio.";
  const whatsapp = `https://wa.me/5598999999999?text=${encodeURIComponent(orderMessage)}`;
  const calories = sizes[sizeIndex].calories + Object.values(selectedToppings).reduce((sum, quantity) => sum + quantity * 42, 0);

  useLayoutEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (selected && !dialog.open) {
      dialog.showModal();
      if (!viewerActiveRef.current) {
        viewerActiveRef.current = true;
        window.dispatchEvent(new Event("mare-roxa:model-open"));
      }
    } else if (!selected && dialog.open) {
      dialog.close();
      if (viewerActiveRef.current) {
        viewerActiveRef.current = false;
        window.dispatchEvent(new Event("mare-roxa:model-close"));
      }
      window.requestAnimationFrame(() => returnFocusRef.current?.focus());
    }
  }, [selected]);

  function enterAfterSplash() {
    if (splashFinishedRef.current) return;
    splashFinishedRef.current = true;
    window.dispatchEvent(new Event("mare-roxa:wave"));
    setStage("login");
  }

  useLayoutEffect(() => {
    if (stage !== "splash") return;
    let finished = false;
    splashFinishedRef.current = false;
    const enter = () => {
      if (finished) return;
      finished = true;
      enterAfterSplash();
    };
    const timer = window.setTimeout(enter, 2500);
    document.addEventListener("pointerdown", enter, { passive: true });
    return () => {
      window.clearTimeout(timer);
      document.removeEventListener("pointerdown", enter);
    };
  }, [stage]);

  useLayoutEffect(() => () => {
    if (entryTimerRef.current !== null) window.clearTimeout(entryTimerRef.current);
  }, []);

  function runViewTransition(update: () => void) {
    const start = (document as ViewTransitionDocument).startViewTransition;
    if (!start || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      update();
      return;
    }
    try { start.call(document, () => flushSync(update)); } catch { update(); }
  }

  function beginSite(name: string) {
    setGreeting(name);
    setDissolving(true);
    window.dispatchEvent(new Event("mare-roxa:reveal-center"));
    entryTimerRef.current = window.setTimeout(() => {
      setStage("site");
      setDissolving(false);
      entryTimerRef.current = null;
    }, 430);
  }

  function enterDemo(name: string, _phone: string) {
    const cleanName = normalizeName(name);
    if (!isValidName(cleanName)) return;
    try { window.localStorage.setItem(greetingStorageKey, cleanName); } catch { /* armazenamento local pode estar indisponível */ }
    beginSite(cleanName);
  }

  function enterAsVisitor() {
    beginSite("visitante");
  }

  function openProduct(product: MenuProduct, trigger: HTMLButtonElement) {
    returnFocusRef.current = trigger;
    const defaults: Record<string, number> = product.traditional ? { "Farinha d’água": 1, "Camarão seco": 1 } : { "Granola da casa": 1, "Banana em rodelas": 1 };
    runViewTransition(() => {
      setSizeIndex(1);
      setShowCalories(false);
      setSelectedToppings(defaults);
      setSelected(product);
    });
  }

  function closeProduct() {
    runViewTransition(() => setSelected(null));
  }

  function changeTopping(name: string, delta: number) {
    const topping = toppings.find((item) => item.name === name);
    if (!topping) return;
    setSelectedToppings((current) => {
      const quantity = current[name] ?? 0;
      if (topping.price === 0) {
        if (delta < 0) return { ...current, [name]: 0 };
        const freeCount = Object.entries(current).filter(([itemName, count]) => count > 0 && toppings.find((item) => item.name === itemName)?.price === 0).length;
        if (quantity === 0 && freeCount >= 4) return current;
        return { ...current, [name]: 1 };
      }
      return { ...current, [name]: Math.max(0, Math.min(5, quantity + delta)) };
    });
  }

  function scrollCarousel(direction: -1 | 1) {
    const carousel = carouselRef.current;
    if (!carousel) return;
    carousel.scrollBy({ left: direction * Math.max(250, carousel.clientWidth * 0.72), behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });
  }

  return (
    <main className="mare-app">
      <SurrealAcaiScene />
      <div className="app-content-layer">
      {stage === "splash" && <SplashScreen onEnter={enterAfterSplash} />}
      {stage === "login" && <DemoLoginCard initialName={storedName} isDissolving={dissolving} onEnter={enterDemo} onVisitor={enterAsVisitor} />}
      {stage === "site" && <div className="site-content">
        <div className="demo-ribbon"><span>São Luís, Maranhão</span><span>Uma marca fictícia, feita de maré e fruta.</span><span>Feito com carinho na ilha <Waves size={14} /></span></div>
        <header className="site-header">
          <a className="brand" href="#inicio" aria-label="Maré Roxa — início"><span className="brand-mark"><Waves size={24} strokeWidth={1.7} /></span><span>maré <b>roxa</b><small>AÇAÍ & JUÇARA DA ILHA</small></span></a>
          <nav aria-label="Navegação principal"><a href="#cardapio">Cardápio</a><a href="#origem">Nossa ilha</a><a href="#pedido">Como pedir</a></nav>
          <div className="header-actions"><span className="header-greeting" aria-live="polite">Oi, {greeting || "visitante"}!</span><a className="header-order" href="#cardapio">Escolha seu copo <ArrowUpRight size={16} /></a></div>
        </header>

        <section className="hero" id="inicio">
          <div className="hero-copy">
            <p className="eyebrow"><span className="eyebrow-line" /> SABOR QUE VEM COM A MARÉ</p>
            <h1>Abre a maré.<br /><em>Encontra</em> teu sabor.</h1>
            <p className="hero-description">Açaí de colherada funda, juçara do nosso jeito e um tantinho de ilha em cada camada.</p>
            <p className="fluid-hint"><Waves size={15} /> Role a página ou toque no fundo para revelar o creme.</p>
            <div className="hero-actions"><a className="button button-gold" href="#cardapio">Ver o cardápio <ArrowDown size={16} /></a><span className="hero-note"><Leaf size={15} /> Feito pra comer sem pressa</span></div>
            <div className="hero-foot"><span>01 / 03</span><span className="hero-foot-rule" /><span>CAMADAS QUE CONTAM HISTÓRIA</span></div>
          </div>
        </section>

        <section className="ticker" aria-label="Mensagem da marca"><div className="ticker-track">AÇAÍ DE VERDADE <span>✳</span> JUÇARA COM HISTÓRIA <span>✳</span> UM TANTINHO DE ILHA <span>✳</span> AÇAÍ DE VERDADE <span>✳</span> JUÇARA COM HISTÓRIA <span>✳</span></div></section>

        <section className="menu-section section-wrap" id="cardapio">
          <div className="section-heading"><div><p className="eyebrow eyebrow-dark">O CARDÁPIO DA MARÉ</p><h2>Qual vai ser<br />a tua <em>onda?</em></h2></div><p className="section-intro">Do roxinho clássico à juçara com gosto de casa. Escolhe teu tamanho, monta do teu jeito e deixa a colher fazer o resto.</p></div>
          <div className="size-legend"><span>TAMANHO · PREÇO A PARTIR DE</span>{sizes.map((size, index) => <span key={size.label}>{size.label} <b>{brl(Math.min(...products.map((product) => product.prices[index])) )}</b></span>)}</div>
          <div className="carousel-toolbar"><p>ESCOLHE UM COPO · ARRASTE PARA DESCOBRIR</p><div className="carousel-arrows"><button type="button" aria-label="Copos anteriores" onClick={() => scrollCarousel(-1)}><ArrowLeft size={18} /></button><button type="button" aria-label="Próximos copos" onClick={() => scrollCarousel(1)}><ArrowRight size={18} /></button></div></div>
          <div className="menu-carousel" ref={carouselRef} role="list" aria-label="Copos prontos da Maré Roxa">
            {products.map((product) => <article className="card menu-card" key={product.id} role="listitem">
              <button className="menu-card-button" type="button" onClick={(event) => openProduct(product, event.currentTarget)} aria-label={`Abrir o copo ${product.name} em 3D; a partir de ${brl(product.prices[0])}`}>
                <span className="cup-art-wrap" style={{ viewTransitionName: `cup-${product.id}` }}><ProductCupIllustration productId={product.id} /></span>
                <span className="menu-card-content"><span className="product-badge">{product.badge}</span><span className="product-title">{product.name}</span><span className="product-description">{product.description}</span><span className="product-price">a partir de <b>{brl(product.prices[0])}</b><ArrowUpRight size={17} /></span></span>
              </button>
            </article>)}
          </div>
          <p className="price-note">Valores ilustrativos para esta experiência demonstrativa. A gente ainda não está recebendo pedidos.</p>
        </section>

        <section className="origin-section" id="origem">
          <div className="origin-image"><div className="origin-sun" /><div className="origin-photo-caption">CULTURA DE COLHER<br /><span>MARACANÃ · SÃO LUÍS</span></div><div className="origin-quote-mark">“</div></div>
          <div className="origin-copy"><p className="eyebrow">UM PÉ NA ILHA, OUTRO NA MARÉ</p><h2>Juçara tem<br />gosto de <em>origem.</em></h2><p>Por aqui, o açaí também atende por juçara. No Maracanã, ela chega à mesa com farinha d’água, camarão seco — e muita conversa boa em volta.</p><p>A Maré Roxa é uma homenagem imaginada a esse jeito maranhense de celebrar a fruta. Tradição e novidade, na mesma colherada.</p><a href="#cardapio" className="text-link">Descobre o sabor da ilha <ArrowRight size={17} /></a><span className="origin-seal"><Waves size={20} /><span>ILHA DE<br />SÃO LUÍS</span></span></div>
        </section>

        <section className="order-section" id="pedido"><div className="order-wave"><Waves /></div><p className="eyebrow">A PRÓXIMA COLHERADA É TUA</p><h2>Feito pra descobrir.<br /><em>Bom de compartilhar.</em></h2><p>Abre o cardápio, monta teu copo e conhece uma ideia de sabor da ilha.</p><a href="#cardapio" className="button button-cream">Montar meu copo <ArrowUpRight size={16} /></a><span className="order-note">Pedidos e contato são ilustrativos. Maré Roxa é uma marca fictícia.</span></section>

        <footer className="site-footer"><a className="brand brand-footer" href="#inicio"><span className="brand-mark"><Waves size={23} /></span><span>maré <b>roxa</b><small>AÇAÍ & JUÇARA DA ILHA</small></span></a><p>Uma homenagem saborosa à Ilha de São Luís.</p><div><a href="#cardapio">Cardápio</a><a href="#origem">Nossa ilha</a><a href="#pedido">Como pedir</a></div><span className="footer-copy">© 2026 MARÉ ROXA · PROJETO DEMONSTRATIVO</span></footer>
        <a className="floating-whatsapp" href="#pedido" aria-label="Ver informações demonstrativas sobre pedido"><span><ArrowRight size={15} /></span><span>COMO PEDIR</span></a>

        <dialog className="viewer-dialog" ref={dialogRef} onCancel={(event) => { event.preventDefault(); closeProduct(); }} onClick={(event) => { if (event.target === dialogRef.current) closeProduct(); }} aria-labelledby="viewer-title">
          {selected && <div className="viewer-shell">
            <div className="viewer-stage-shell">
              <button className="viewer-close" type="button" aria-label="Fechar visualizador 3D" onClick={closeProduct}><X size={20} /></button>
              <div className="viewer-cup-transition" style={{ viewTransitionName: `cup-${selected.id}` }}><Cup3DViewer key={selected.id} productId={selected.id} productName={selected.name} /></div>
            </div>
            <aside className="viewer-panel card">
              <p className="eyebrow eyebrow-dark">{selected.badge.toUpperCase()} · MONTA A TUA MARÉ</p>
              <h2 id="viewer-title">{selected.name}</h2>
              <p className="viewer-description">{selected.description}</p>
              <fieldset className="size-options"><legend>Tamanho do copo</legend>{sizes.map((size, index) => <label className={sizeIndex === index ? "size-option active" : "size-option"} key={size.label}><input type="radio" name="size" value={index} checked={sizeIndex === index} onChange={() => setSizeIndex(index)} /><span><b>{size.label}</b><small>{size.short}</small></span><strong>{brl(selected.prices[index])}</strong></label>)}</fieldset>
              <fieldset className="topping-options"><legend>Até 4 grátis · adicionais pagos por unidade</legend>{toppings.map((topping) => {
                const quantity = selectedToppings[topping.name] ?? 0;
                return topping.price === 0 ? <div className="topping-row" key={topping.name}><label className="topping-select"><input type="checkbox" checked={quantity > 0} onChange={() => changeTopping(topping.name, quantity > 0 ? -1 : 1)} /><span className="checkmark"><Check size={13} /></span><span>{topping.name}</span></label><b className="free-label">grátis</b></div> : <div className="topping-row" key={topping.name}><span className="topping-name">{topping.name}</span><div className="addon-control"><button type="button" aria-label={`Diminuir ${topping.name}`} disabled={!quantity} onClick={() => changeTopping(topping.name, -1)}><Minus size={12} /></button><span aria-live="polite">{quantity}</span><button type="button" aria-label={`Adicionar ${topping.name}`} onClick={() => changeTopping(topping.name, 1)}><Plus size={12} /></button></div><b className="paid-label">+ {brl(topping.price)} / un.</b></div>;
              })}</fieldset>
              <button className="calories-toggle" type="button" aria-expanded={showCalories} aria-controls="calories-estimate" onClick={() => setShowCalories((value) => !value)}>{showCalories ? "Ocultar estimativa" : "Ver estimativa de calorias"}<span>{showCalories ? "−" : "+"}</span></button>
              <p className="calories-copy" id="calories-estimate" aria-live="polite" hidden={!showCalories}>Aprox. {calories} kcal. Estimativa ilustrativa, varia conforme a montagem.</p>
              <div className="dialog-total" aria-live="polite" aria-atomic="true"><span>Total do copo</span><b>{brl(total)}</b></div>
              <a className="dialog-add" href={whatsapp} target="_blank" rel="noopener noreferrer">Pedir pelo WhatsApp <ArrowUpRight size={17} /></a>
              <p className="dialog-disclaimer">Demonstração fictícia. O site só prepara a mensagem; você decide se abre e envia pelo WhatsApp.</p>
            </aside>
          </div>}
        </dialog>
      </div>}
      </div>
    </main>
  );
}

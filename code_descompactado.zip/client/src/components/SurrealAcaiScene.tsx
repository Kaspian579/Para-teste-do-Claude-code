import { createPortal } from "react-dom";
import { useEffect, useRef, useState } from "react";
import type { CSSProperties } from "react";
import type * as ThreeTypes from "three";

type RuntimeImport = (specifier: string) => Promise<unknown>;
type ThreeModule = typeof import("three");
type ComposerModule = typeof import("three/addons/postprocessing/EffectComposer.js");
type RenderPassModule = typeof import("three/addons/postprocessing/RenderPass.js");
type BloomModule = typeof import("three/addons/postprocessing/UnrealBloomPass.js");
type OutputPassModule = typeof import("three/addons/postprocessing/OutputPass.js");
type SceneStatus = {
  webgl: "carregando" | "ok" | "falhou";
  fps: number;
  bloom: boolean;
  toppings: number;
  segments: number;
  adaptive: boolean;
  reason: string;
};
type OrbitSpec = {
  mesh: ThreeTypes.InstancedMesh;
  index: number;
  angle: number;
  radius: number;
  height: number;
  speed: number;
  tilt: number;
  scale: number;
  boostUntil: number;
  localPosition: ThreeTypes.Vector3;
};
type ToppingBatch = {
  mesh: ThreeTypes.InstancedMesh;
  specs: OrbitSpec[];
  activeCount: number;
  maxCount: number;
};
type RingWave = { x: number; y: number; start: number; amplitude: number };
type BubbleSpec = { index: number; x: number; y: number; z: number; speed: number; scale: number };

const runtimeImport = new Function("specifier", "return import(specifier)") as RuntimeImport;
const WAVE_COUNT = 10;
const WAVE_LIFE = 1.2;
const MAX_MOBILE_TOPPINGS = 150;
const clamp = (value: number, min: number, max: number) => Math.max(min, Math.min(max, value));
const mix = (a: number, b: number, amount: number) => a + (b - a) * amount;

const surfaceVertexShader = `precision highp float;
in vec3 position;
in vec2 uv;
uniform mat4 modelViewMatrix;
uniform mat4 projectionMatrix;
uniform float uTime;
out vec2 vUv;
out float vNoise;
out float vFogDepth;
float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}
float noise2(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x),
             mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
  float value = 0.0;
  float amplitude = 0.5;
  mat2 turn = mat2(1.62, 1.18, -1.18, 1.62);
  for (int i = 0; i < 3; i++) {
    value += amplitude * noise2(p);
    p = turn * p;
    amplitude *= 0.5;
  }
  return value;
}
void main() {
  vUv = uv;
  vNoise = fbm(uv * 7.0 + vec2(uTime * 0.035, -uTime * 0.022));
  vec2 p = uv - vec2(0.5);
  float radial = length(p);
  vec3 displaced = position;
  displaced.z += (vNoise - 0.5) * 0.070 + sin(radial * 50.0 - uTime * 1.35) * 0.008;
  vec4 viewPosition = modelViewMatrix * vec4(displaced, 1.0);
  vFogDepth = -viewPosition.z;
  gl_Position = projectionMatrix * viewPosition;
}`;

const surfaceFragmentShader = `precision highp float;
in vec2 vUv;
in float vNoise;
in float vFogDepth;
uniform float uTime;
uniform vec4 uWaves[10];
uniform vec3 uFogColor;
uniform float uFogDensity;
out vec4 fragColor;
float hash21(vec2 p) {
  p = fract(p * vec2(123.34, 456.21));
  p += dot(p, p + 45.32);
  return fract(p.x * p.y);
}
float noise2(vec2 p) {
  vec2 i = floor(p);
  vec2 f = fract(p);
  f = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash21(i), hash21(i + vec2(1.0, 0.0)), f.x),
             mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), f.x), f.y);
}
float fbm(vec2 p) {
  float value = 0.0;
  float amplitude = 0.5;
  mat2 turn = mat2(1.62, 1.18, -1.18, 1.62);
  for (int i = 0; i < 3; i++) {
    value += amplitude * noise2(p);
    p = turn * p;
    amplitude *= 0.5;
  }
  return value;
}
void main() {
  vec2 centerUv = vUv - vec2(0.5);
  float radius = length(centerUv);
  if (radius > 0.451) discard;

  float marbling = fbm(vUv * 6.3 + vec2(uTime * 0.027, -uTime * 0.018));
  float veins = fbm(vUv * 15.0 + vec2(-uTime * 0.016, uTime * 0.023));
  vec3 acaiDark = vec3(0.165, 0.039, 0.180);
  vec3 acaiMid = vec3(0.294, 0.071, 0.282);
  vec3 acaiLight = vec3(0.420, 0.118, 0.357);
  vec3 color = mix(acaiDark, acaiMid, smoothstep(0.05, 0.72, marbling));
  color = mix(color, acaiLight, smoothstep(0.54, 0.92, veins) * 0.58);

  float wetHighlight = pow(max(0.0, 1.0 - abs(marbling - 0.55) * 3.2), 18.0);
  wetHighlight += pow(max(0.0, 1.0 - abs(veins - 0.48) * 7.0), 25.0) * 0.32;
  color += vec3(0.72, 0.45, 0.70) * wetHighlight * 0.23;

  float grain = step(0.968, noise2(vUv * vec2(116.0, 91.0) + uTime * 0.008));
  color = mix(color, vec3(0.72, 0.48, 0.27), grain * 0.20);

  float waveInk = 0.0;
  float fineRing = 0.0;
  for (int i = 0; i < 10; i++) {
    float age = uTime - uWaves[i].z;
    if (age >= 0.0 && age < 1.2) {
      vec2 delta = (vUv - uWaves[i].xy) * vec2(1.0, 0.92);
      float distanceFromTouch = length(delta);
      float progress = age / 1.2;
      float ringRadius = progress * 0.47;
      float fade = (1.0 - smoothstep(0.68, 1.0, progress)) * uWaves[i].w;
      float ring = exp(-pow((distanceFromTouch - ringRadius) * 75.0, 2.0));
      float softOpen = exp(-pow((distanceFromTouch - ringRadius) * 16.0, 2.0));
      waveInk = max(waveInk, max(ring * 0.94, softOpen * 0.68) * fade);
      fineRing = max(fineRing, ring * fade);
    }
  }
  vec3 cream = vec3(0.953, 0.902, 0.812);
  color = mix(color, cream, clamp(waveInk, 0.0, 0.96));
  color += vec3(0.98, 0.78, 0.52) * fineRing * 0.22;

  vec2 lightDirection = normalize(vec2(-0.55, 0.78));
  float fakeNormal = dot(vec2(dFdx(marbling), dFdy(marbling)), lightDirection);
  float specular = pow(max(0.0, 0.42 - fakeNormal), 18.0) * 0.20;
  color += vec3(1.0, 0.84, 0.66) * specular;

  float fogAmount = 1.0 - exp(-uFogDensity * uFogDensity * vFogDepth * vFogDepth);
  color = mix(color, uFogColor, clamp(fogAmount * 0.22, 0.0, 0.32));
  fragColor = vec4(color, 1.0);
}`;

const lowPowerSurfaceFragmentShader = `precision highp float;
in vec2 vUv;
in float vNoise;
in float vFogDepth;
uniform float uTime;
uniform vec4 uWaves[10];
uniform vec3 uFogColor;
uniform float uFogDensity;
out vec4 fragColor;
void main() {
  vec2 centerUv = vUv - vec2(0.5);
  if (length(centerUv) > 0.451) discard;

  float marbling = 0.5 + 0.5 * sin(vUv.x * 18.0 + sin(vUv.y * 14.0 + uTime * 0.18) + (vNoise - 0.5) * 2.0);
  float veins = 0.5 + 0.5 * sin(vUv.y * 20.0 - vUv.x * 8.0 + uTime * 0.12);
  vec3 color = mix(vec3(0.165, 0.039, 0.180), vec3(0.294, 0.071, 0.282), smoothstep(0.08, 0.92, marbling));
  color = mix(color, vec3(0.420, 0.118, 0.357), smoothstep(0.64, 0.91, veins) * 0.28);
  float wetHighlight = pow(max(0.0, 1.0 - abs(marbling - 0.55) * 3.2), 12.0) * 0.12;
  color += vec3(0.72, 0.45, 0.70) * wetHighlight;

  float waveInk = 0.0;
  float fineRing = 0.0;
  for (int i = 0; i < 10; i++) {
    float age = uTime - uWaves[i].z;
    if (age >= 0.0 && age < 1.2) {
      float distanceFromTouch = length((vUv - uWaves[i].xy) * vec2(1.0, 0.92));
      float progress = age / 1.2;
      float ringRadius = progress * 0.47;
      float fade = (1.0 - smoothstep(0.68, 1.0, progress)) * uWaves[i].w;
      float ring = exp(-pow((distanceFromTouch - ringRadius) * 75.0, 2.0));
      float softOpen = exp(-pow((distanceFromTouch - ringRadius) * 16.0, 2.0));
      waveInk = max(waveInk, max(ring * 0.94, softOpen * 0.68) * fade);
      fineRing = max(fineRing, ring * fade);
    }
  }
  color = mix(color, vec3(0.953, 0.902, 0.812), clamp(waveInk, 0.0, 0.96));
  color += vec3(0.98, 0.78, 0.52) * fineRing * 0.22;

  float fogAmount = smoothstep(4.0, 24.0, vFogDepth) * clamp(uFogDensity * 6.0, 0.0, 0.3);
  color = mix(color, uFogColor, fogAmount);
  fragColor = vec4(color, 1.0);
}`;

function validateShaderProgram(gl: WebGL2RenderingContext, vertexSource: string, fragmentSource: string) {
  let vertex: WebGLShader | null = null;
  let fragment: WebGLShader | null = null;
  let program: WebGLProgram | null = null;
  try {
    const compile = (type: number, source: string, label: string) => {
      const shader = gl.createShader(type);
      if (!shader) throw new Error(`Não foi possível criar o ${label} shader.`);
      const body = source.replace(/^#version 300 es\s*\n/, "");
      gl.shaderSource(shader, `#version 300 es\n${body}`);
      gl.compileShader(shader);
      if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
        const message = gl.getShaderInfoLog(shader) || `Falha sem log ao compilar ${label}.`;
        gl.deleteShader(shader);
        throw new Error(`${label}: ${message}`);
      }
      return shader;
    };
    vertex = compile(gl.VERTEX_SHADER, vertexSource, "vertex");
    fragment = compile(gl.FRAGMENT_SHADER, fragmentSource, "fragment");
    program = gl.createProgram();
    if (!program) throw new Error("Não foi possível criar o programa WebGL.");
    gl.attachShader(program, vertex);
    gl.attachShader(program, fragment);
    gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) {
      throw new Error(`Link GLSL: ${gl.getProgramInfoLog(program) || "falha sem log"}`);
    }
  } finally {
    if (program) gl.deleteProgram(program);
    if (vertex) gl.deleteShader(vertex);
    if (fragment) gl.deleteShader(fragment);
  }
}

function createWoodTexture(THREE: ThreeModule) {
  const textureCanvas = document.createElement("canvas");
  textureCanvas.width = 768;
  textureCanvas.height = 384;
  const ctx = textureCanvas.getContext("2d");
  if (!ctx) throw new Error("Canvas 2D indisponível para a textura procedural da madeira.");
  const base = ctx.createLinearGradient(0, 0, textureCanvas.width, textureCanvas.height);
  base.addColorStop(0, "#32170f");
  base.addColorStop(0.34, "#663420");
  base.addColorStop(0.7, "#3d1b14");
  base.addColorStop(1, "#7a4228");
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, textureCanvas.width, textureCanvas.height);
  for (let index = 0; index < 115; index++) {
    const y = (index / 115) * textureCanvas.height;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.bezierCurveTo(170, y + Math.random() * 18 - 9, 430, y + Math.random() * 24 - 12, textureCanvas.width, y + Math.random() * 20 - 10);
    ctx.strokeStyle = index % 4 === 0 ? "rgba(231,167,101,.19)" : "rgba(15,5,5,.15)";
    ctx.lineWidth = 0.4 + Math.random() * 2.5;
    ctx.stroke();
  }
  for (let index = 0; index < 9; index++) {
    const x = Math.random() * textureCanvas.width;
    const y = Math.random() * textureCanvas.height;
    ctx.beginPath();
    ctx.ellipse(x, y, 14 + Math.random() * 23, 3 + Math.random() * 7, Math.random() * 0.3, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(12,4,4,.26)";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.beginPath();
    ctx.ellipse(x + 2, y + 1, 7 + Math.random() * 9, 1.5 + Math.random() * 3, Math.random() * 0.3, 0, Math.PI * 2);
    ctx.strokeStyle = "rgba(244,188,121,.15)";
    ctx.lineWidth = 1;
    ctx.stroke();
  }
  const texture = new THREE.CanvasTexture(textureCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  texture.anisotropy = 8;
  return texture;
}

function makeLeafShape(THREE: ThreeModule) {
  const shape = new THREE.Shape();
  shape.moveTo(0, 0);
  shape.quadraticCurveTo(0.18, 0.34, 0.02, 0.82);
  shape.quadraticCurveTo(-0.23, 0.45, 0, 0);
  return new THREE.ShapeGeometry(shape, 12);
}

function disposeScene(scene: ThreeTypes.Scene | null) {
  if (!scene) return;
  const textures = new Set<ThreeTypes.Texture>();
  const disposedMaterials = new Set<ThreeTypes.Material>();
  scene.traverse((child) => {
    const mesh = child as ThreeTypes.Mesh;
    mesh.geometry?.dispose();
    const materials = Array.isArray(mesh.material) ? mesh.material : mesh.material ? [mesh.material] : [];
    for (const material of materials) {
      if (disposedMaterials.has(material)) continue;
      disposedMaterials.add(material);
      const maps = material as ThreeTypes.Material & {
        map?: ThreeTypes.Texture | null;
        bumpMap?: ThreeTypes.Texture | null;
        roughnessMap?: ThreeTypes.Texture | null;
        normalMap?: ThreeTypes.Texture | null;
        metalnessMap?: ThreeTypes.Texture | null;
      };
      [maps.map, maps.bumpMap, maps.roughnessMap, maps.normalMap, maps.metalnessMap].forEach((texture) => {
        if (texture) textures.add(texture);
      });
      material.dispose();
    }
  });
  textures.forEach((texture) => texture.dispose());
}

export function SurrealAcaiScene() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mode, setMode] = useState<"loading" | "webgl" | "fallback">("loading");
  const [frameSnapshot, setFrameSnapshot] = useState<string | null>(null);
  const [diagnostics, setDiagnostics] = useState<SceneStatus>({
    webgl: "carregando",
    fps: 0,
    bloom: false,
    toppings: 0,
    segments: 0,
    adaptive: false,
    reason: "",
  });
  const debugEnabled = typeof window !== "undefined" && new URLSearchParams(window.location.search).has("debug");

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let alive = true;
    let cleaned = false;
    let frameCaptured = false;
    let three: ThreeModule | null = null;
    let renderer: ThreeTypes.WebGLRenderer | null = null;
    let composer: InstanceType<ComposerModule["EffectComposer"]> | null = null;
    let scene: ThreeTypes.Scene | null = null;
    let camera: ThreeTypes.PerspectiveCamera | null = null;
    let composition: ThreeTypes.Group | null = null;
    let bowlGroup: ThreeTypes.Group | null = null;
    let surface: ThreeTypes.Mesh<ThreeTypes.PlaneGeometry, ThreeTypes.RawShaderMaterial> | null = null;
    let surfaceMaterial: ThreeTypes.RawShaderMaterial | null = null;
    let toppingBatches: ToppingBatch[] = [];
    let orbiters: OrbitSpec[] = [];
    let bubbles: ThreeTypes.InstancedMesh | null = null;
    let bubbleSpecs: BubbleSpec[] = [];
    let goldDust: ThreeTypes.Points<ThreeTypes.BufferGeometry, ThreeTypes.PointsMaterial> | null = null;
    let dustPositions: Float32Array | null = null;
    let dustSpeeds: Float32Array | null = null;
    let resizeObserver: ResizeObserver | null = null;
    let animationRunning = false;
    let scrollFrame = 0;
    let activePointer: number | null = null;
    let previousPointerX = 0;
    let elapsed = 0;
    let startTime = 0;
    let hiddenAt: number | null = null;
    let previousFrame = 0;
    let frameCount = 0;
    let fpsWindowStart = 0;
    let fpsAverage = 60;
    let lowFpsWindows = 0;
    let adaptive = false;
    let adaptiveStage = 0;
    let lowPowerDevice = false;
    let isMobile = false;
    let reducedMotion = false;
    let segmentCount = 200;
    let width = Math.max(1, window.innerWidth);
    let height = Math.max(1, window.innerHeight);
    let rotationVelocity = 0;
    let previousScrollY = window.scrollY;
    let pendingScrollY = previousScrollY;
    let lastScrollTime = performance.now();
    let cameraMoving = false;
    let waves: RingWave[] = [];
    let waveUniforms: ThreeTypes.Vector4[] = [];
    let toppingCount = 0;
    let onResize: () => void = () => {};
    let onScroll: () => void = () => {};
    let onPointerDown: (event: PointerEvent) => void = () => {};
    let onPointerMove: (event: PointerEvent) => void = () => {};
    let onPointerUp: (event: PointerEvent) => void = () => {};
    let onTouchStart: (event: TouchEvent) => void = () => {};
    let onTouchMove: (event: TouchEvent) => void = () => {};
    let onTouchEnd: () => void = () => {};
    let onContextLost: (event: Event) => void = () => {};
    let onVisibilityChange: () => void = () => {};
    let onSplashWave: () => void = () => {};
    let onRevealCenter: () => void = () => {};
    let motionQuery: MediaQueryList | null = null;
    let onMotionPreferenceChange: (event: MediaQueryListEvent) => void = () => {};
    let renderFrame: (now: number) => void = () => {};
    let runtimeCleanup = () => {};
    let setFallback = (_error: unknown) => {};

    const debugStatus = (patch: Partial<SceneStatus>) => {
      if (alive && debugEnabled) setDiagnostics((previous) => ({ ...previous, ...patch }));
    };
    const cleanup = () => {
      if (cleaned) return;
      cleaned = true;
      renderer?.setAnimationLoop(null);
      animationRunning = false;
      if (scrollFrame) window.cancelAnimationFrame(scrollFrame);
      resizeObserver?.disconnect();
      window.removeEventListener("resize", onResize);
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("pointerdown", onPointerDown);
      window.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("pointercancel", onPointerUp);
      window.removeEventListener("touchstart", onTouchStart);
      window.removeEventListener("touchmove", onTouchMove);
      window.removeEventListener("touchend", onTouchEnd);
      window.removeEventListener("touchcancel", onTouchEnd);
      window.removeEventListener("mare-roxa:wave", onSplashWave);
      window.removeEventListener("mare-roxa:reveal-center", onRevealCenter);
      document.removeEventListener("visibilitychange", onVisibilityChange);
      motionQuery?.removeEventListener("change", onMotionPreferenceChange);
      canvas.removeEventListener("webglcontextlost", onContextLost);
      composer?.dispose();
      disposeScene(scene);
      renderer?.dispose();
      renderer = null;
      scene = null;
      camera = null;
      composition = null;
      bowlGroup = null;
      surface = null;
      surfaceMaterial = null;
      toppingBatches = [];
      orbiters = [];
      bubbles = null;
      bubbleSpecs = [];
      goldDust = null;
      dustPositions = null;
      dustSpeeds = null;
      waveUniforms = [];
      composer = null;
    };
    runtimeCleanup = cleanup;
    setFallback = (error: unknown) => {
      if (!alive) return;
      const reason = error instanceof Error ? error.message : String(error || "WebGL indisponível");
      cleanup();
      setFrameSnapshot(null);
      setMode("fallback");
      debugStatus({ webgl: "falhou", bloom: false, reason: reason.slice(0, 320) });
    };
    const startRenderer = () => {
      if (!renderer || animationRunning || !alive) return;
      if (document.hidden) {
        if (hiddenAt === null) hiddenAt = performance.now();
        return;
      }
      animationRunning = true;
      const now = performance.now();
      previousFrame = now;
      fpsWindowStart = now;
      frameCount = 0;
      lowFpsWindows = 0;
      renderer.setAnimationLoop(renderFrame);
    };
    const stopRenderer = () => {
      if (!renderer || !animationRunning) return;
      renderer.setAnimationLoop(null);
      animationRunning = false;
    };

    const init = async () => {
      try {
        three = (await runtimeImport("three")) as ThreeModule;
        if (!alive) return;
        const THREE = three;
        isMobile = window.matchMedia("(max-width: 768px)").matches;
        motionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
        reducedMotion = motionQuery.matches;
        const cores = navigator.hardwareConcurrency || 4;
        const memory = (navigator as Navigator & { deviceMemory?: number }).deviceMemory || 4;
        lowPowerDevice = !isMobile && (cores <= 8 || memory <= 8);
        adaptiveStage = lowPowerDevice ? 1 : 0;
        adaptive = lowPowerDevice;
        segmentCount = isMobile ? 120 : lowPowerDevice ? 112 : 200;
        width = Math.max(1, window.innerWidth);
        height = Math.max(1, window.innerHeight);
        const selectedSurfaceFragmentShader = isMobile || lowPowerDevice ? lowPowerSurfaceFragmentShader : surfaceFragmentShader;
        const makeSurfaceGeometry = (segments: number) => new THREE.PlaneGeometry(3.74, 3.74, segments, segments);
        const raycaster = new THREE.Raycaster();
        const mouse = new THREE.Vector2();
        const dummy = new THREE.Object3D();
        const lookTarget = new THREE.Vector3(0, 0.74, 0);
        const targetCameraPosition = new THREE.Vector3();
        const targetLookAt = new THREE.Vector3();
        waveUniforms = Array.from({ length: WAVE_COUNT }, () => new THREE.Vector4(0.5, 0.5, -99, 0));
        const spawnWave = (x: number, y: number, amplitude = 0.8) => {
          waves = waves.filter((wave) => elapsed - wave.start < WAVE_LIFE);
          if (waves.length >= WAVE_COUNT) waves.shift();
          waves.push({ x: clamp(x, 0.03, 0.97), y: clamp(y, 0.03, 0.97), start: elapsed, amplitude: clamp(amplitude, 0.18, 1) });
          for (let index = 0; index < WAVE_COUNT; index++) {
            const wave = waves[index];
            waveUniforms[index].set(wave?.x ?? 0.5, wave?.y ?? 0.5, wave?.start ?? -99, wave?.amplitude ?? 0);
          }
          if (surfaceMaterial) surfaceMaterial.uniforms.uWaves.value = waveUniforms;
          startRenderer();
        };
        const isInteractiveTarget = (target: EventTarget | null) => {
          if (!(target instanceof Element)) return false;
          return Boolean(target.closest("button, a, input, label, .card, .viewer-panel, dialog"));
        };
        const updateScrollPose = (scrollY: number, smooth = true) => {
          if (!camera || !composition || !bowlGroup) return;
          const menuElement = document.getElementById("cardapio");
          const originElement = document.getElementById("origem");
          const menuTop = Math.max(window.innerHeight * 0.7, menuElement ? window.scrollY + menuElement.getBoundingClientRect().top : window.innerHeight * 1.3);
          const originTop = Math.max(menuTop + window.innerHeight * 0.55, originElement ? window.scrollY + originElement.getBoundingClientRect().top : menuTop + window.innerHeight * 1.2);
          const overhead = clamp((scrollY - menuTop * 0.18) / Math.max(1, menuTop * 0.74), 0, 1);
          const corner = clamp((scrollY - originTop) / Math.max(1, window.innerHeight * 0.95), 0, 1);
          const frontPosition = new THREE.Vector3(0, 5.0, 7.7);
          const overheadPosition = new THREE.Vector3(0, 6.5, 1.28);
          const lowerPosition = new THREE.Vector3(4.35, 3.55, 8.0);
          targetCameraPosition.copy(frontPosition).lerp(overheadPosition, overhead).lerp(lowerPosition, corner);
          targetLookAt.set(0, 0.74, 0).lerp(new THREE.Vector3(0, 0.24, 0), overhead).lerp(new THREE.Vector3(0.68, 0.42, 0), corner);
          const ease = !smooth || reducedMotion ? 1 : 1 - Math.exp(-3.2 / 60);
          camera.position.lerp(targetCameraPosition, ease);
          lookTarget.lerp(targetLookAt, ease);
          camera.lookAt(lookTarget);
          composition.position.x = mix(0, 2.05, corner);
          composition.position.y = mix(0, 0.3, corner);
          bowlGroup.scale.setScalar(mix(1.35, 0.62, corner));
          cameraMoving = camera.position.distanceToSquared(targetCameraPosition) > 0.001 || lookTarget.distanceToSquared(targetLookAt) > 0.001;
        };
        startTime = performance.now();
        const spawnScrollWaves = (delta: number, elapsedMs: number) => {
          if (reducedMotion || Math.abs(delta) < 54) return;
          const velocity = Math.abs(delta) / Math.max(16, elapsedMs);
          const count = clamp(Math.round(velocity * 2.4), 1, 4);
          for (let index = 0; index < count; index++) {
            spawnWave(0.24 + Math.random() * 0.52, 0.22 + Math.random() * 0.56, clamp(0.25 + velocity * 0.7, 0.25, 1));
          }
        };
        const boostNearestOrbiter = (clientX: number, clientY: number) => {
          if (!camera || !bowlGroup || reducedMotion || orbiters.length === 0) return;
          camera.updateMatrixWorld(true);
          bowlGroup.updateMatrixWorld(true);
          let nearest: OrbitSpec | null = null;
          let nearestDistance = Number.POSITIVE_INFINITY;
          const point = new THREE.Vector3();
          for (const candidate of orbiters) {
            const batch = toppingBatches.find((entry) => entry.mesh === candidate.mesh);
            if (!batch || candidate.index >= batch.activeCount) continue;
            point.copy(candidate.localPosition);
            bowlGroup.localToWorld(point).project(camera);
            const screenX = ((point.x + 1) * 0.5) * width;
            const screenY = ((1 - point.y) * 0.5) * height;
            const distance = Math.hypot(screenX - clientX, screenY - clientY);
            if (distance < nearestDistance) {
              nearest = candidate;
              nearestDistance = distance;
            }
          }
          if (nearest && nearestDistance < Math.max(180, width * 0.24)) nearest.boostUntil = elapsed + 1.15;
        };
        const interactAt = (clientX: number, clientY: number, target: EventTarget | null) => {
          if (!alive || isInteractiveTarget(target) || !camera || !surface) return;
          mouse.set((clientX / width) * 2 - 1, 1 - (clientY / height) * 2);
          camera.updateMatrixWorld(true);
          bowlGroup?.updateMatrixWorld(true);
          raycaster.setFromCamera(mouse, camera);
          const hit = raycaster.intersectObject(surface, false)[0];
          if (hit?.uv && hit.uv.distanceTo(new THREE.Vector2(0.5, 0.5)) < 0.45) {
            spawnWave(hit.uv.x, hit.uv.y, clamp(0.62 + Math.random() * 0.34, 0.55, 1));
          } else if (!reducedMotion) {
            boostNearestOrbiter(clientX, clientY);
            startRenderer();
          }
        };

        onScroll = () => {
          if (reducedMotion) {
            pendingScrollY = window.scrollY;
            previousScrollY = pendingScrollY;
            lastScrollTime = performance.now();
            return;
          }
          pendingScrollY = window.scrollY;
          if (scrollFrame) return;
          scrollFrame = window.requestAnimationFrame(() => {
            scrollFrame = 0;
            const now = performance.now();
            const delta = pendingScrollY - previousScrollY;
            updateScrollPose(pendingScrollY);
            spawnScrollWaves(delta, now - lastScrollTime);
            previousScrollY = pendingScrollY;
            lastScrollTime = now;
            startRenderer();
          });
        };
        onPointerDown = (event) => {
          if (event.isPrimary === false || isInteractiveTarget(event.target)) return;
          activePointer = event.pointerId;
          previousPointerX = event.clientX;
          interactAt(event.clientX, event.clientY, event.target);
          startRenderer();
        };
        onPointerMove = (event) => {
          if (activePointer !== event.pointerId || isInteractiveTarget(event.target)) return;
          const dx = event.clientX - previousPointerX;
          previousPointerX = event.clientX;
          if (Math.abs(dx) > 0.5 && !reducedMotion) rotationVelocity = clamp(rotationVelocity + dx * 0.0009, -0.34, 0.34);
          if (surface) {
            mouse.set((event.clientX / width) * 2 - 1, 1 - (event.clientY / height) * 2);
            camera?.updateMatrixWorld(true);
            if (camera) raycaster.setFromCamera(mouse, camera);
            const hit = camera ? raycaster.intersectObject(surface, false)[0] : undefined;
            if (hit?.uv && hit.uv.distanceTo(new THREE.Vector2(0.5, 0.5)) < 0.45 && Math.abs(dx) > 9) {
              spawnWave(hit.uv.x, hit.uv.y, clamp(Math.abs(dx) / 80, 0.18, 0.65));
            }
          }
          startRenderer();
        };
        onPointerUp = (event) => { if (activePointer === event.pointerId) activePointer = null; };
        onTouchStart = (event) => {
          if (isInteractiveTarget(event.target)) { activePointer = null; return; }
          const touch = event.changedTouches.item(0);
          if (!touch) return;
          activePointer = -1;
          previousPointerX = touch.clientX;
          interactAt(touch.clientX, touch.clientY, event.target);
        };
        onTouchMove = (event) => {
          if (activePointer !== -1 || isInteractiveTarget(event.target)) return;
          const touch = event.changedTouches.item(0);
          if (!touch) return;
          const dx = touch.clientX - previousPointerX;
          previousPointerX = touch.clientX;
          if (Math.abs(dx) > 0.5 && !reducedMotion) rotationVelocity = clamp(rotationVelocity + dx * 0.0009, -0.34, 0.34);
          if (surface) {
            mouse.set((touch.clientX / width) * 2 - 1, 1 - (touch.clientY / height) * 2);
            camera?.updateMatrixWorld(true);
            if (camera) raycaster.setFromCamera(mouse, camera);
            const hit = camera ? raycaster.intersectObject(surface, false)[0] : undefined;
            if (hit?.uv && hit.uv.distanceTo(new THREE.Vector2(0.5, 0.5)) < 0.45 && Math.abs(dx) > 8) {
              spawnWave(hit.uv.x, hit.uv.y, clamp(Math.abs(dx) / 85, 0.18, 0.6));
            }
          }
          startRenderer();
        };
        onTouchEnd = () => { if (activePointer === -1) activePointer = null; };
        onSplashWave = () => {
          if (reducedMotion) return;
          for (let index = 0; index < 5; index++) {
            const progress = index / 4;
            spawnWave(0.5 + (Math.random() - 0.5) * 0.14, 0.12 + progress * 0.76, 0.52 + progress * 0.28);
          }
        };
        onRevealCenter = () => { if (!reducedMotion) spawnWave(0.5, 0.5, 0.92); };

        renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: !lowPowerDevice, powerPreference: "high-performance" });
        renderer.setClearColor(0x000000, 0);
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, lowPowerDevice ? 1 : 1.5));
        renderer.setSize(width, height, false);
        renderer.outputColorSpace = THREE.SRGBColorSpace;
        renderer.toneMapping = THREE.ACESFilmicToneMapping;
        renderer.toneMappingExposure = 1.06;
        const gl = renderer.getContext() as WebGL2RenderingContext;
        validateShaderProgram(gl, surfaceVertexShader, selectedSurfaceFragmentShader);

        scene = new THREE.Scene();
        scene.background = null;
        scene.fog = new THREE.FogExp2("#210b28", 0.034);
        camera = new THREE.PerspectiveCamera(31, width / height, 0.1, 90);
        camera.position.set(0, 5.0, 7.7);
        camera.lookAt(0, 0.74, 0);
        composition = new THREE.Group();
        scene.add(composition);
        bowlGroup = new THREE.Group();
        composition.add(bowlGroup);

        scene.add(new THREE.HemisphereLight(0xffdfb3, 0x26102b, 2.35));
        const goldKey = new THREE.DirectionalLight(0xf2bd70, 3.25);
        goldKey.position.set(-4.5, 6.5, 5.5);
        scene.add(goldKey);
        const pinkRim = new THREE.DirectionalLight(0xb05a9a, 3.8);
        pinkRim.position.set(4.5, 4.0, -4.0);
        scene.add(pinkRim);
        const creamFill = new THREE.PointLight(0xffe7c6, 92, 20, 2);
        creamFill.position.set(1.4, 5.0, 5.2);
        scene.add(creamFill);
        const rosyBounce = new THREE.PointLight(0xd96eb8, 48, 18, 2);
        rosyBounce.position.set(-4.0, 1.2, 1.0);
        scene.add(rosyBounce);

        const woodTexture = createWoodTexture(THREE);
        const woodMaterial = new THREE.MeshStandardMaterial({ map: woodTexture, color: 0xffffff, roughness: 0.47, metalness: 0.04 });
        const profile = [
          new THREE.Vector2(0.0, 0.11), new THREE.Vector2(0.42, 0.12), new THREE.Vector2(0.91, 0.17),
          new THREE.Vector2(1.39, 0.31), new THREE.Vector2(1.79, 0.54), new THREE.Vector2(2.02, 0.79),
          new THREE.Vector2(2.05, 0.91), new THREE.Vector2(1.95, 0.97), new THREE.Vector2(1.82, 0.88),
          new THREE.Vector2(1.69, 0.65), new THREE.Vector2(1.38, 0.46), new THREE.Vector2(0.78, 0.37),
          new THREE.Vector2(0.0, 0.35),
        ];
        const bowlMesh = new THREE.Mesh(new THREE.LatheGeometry(profile, 96), woodMaterial);
        bowlMesh.castShadow = true;
        bowlMesh.receiveShadow = true;
        bowlGroup.add(bowlMesh);
        const rim = new THREE.Mesh(new THREE.TorusGeometry(1.98, 0.065, 16, 128), woodMaterial);
        rim.rotation.x = -Math.PI / 2;
        rim.position.y = 0.9;
        rim.castShadow = true;
        bowlGroup.add(rim);
        const rimGlint = new THREE.Mesh(new THREE.TorusGeometry(1.91, 0.014, 8, 128), new THREE.MeshStandardMaterial({ color: 0xc8964a, metalness: 0.66, roughness: 0.24, emissive: 0x492714, emissiveIntensity: 0.16 }));
        rimGlint.rotation.x = -Math.PI / 2;
        rimGlint.position.y = 0.92;
        bowlGroup.add(rimGlint);
        const foot = new THREE.Mesh(new THREE.CylinderGeometry(0.52, 0.64, 0.21, 64), woodMaterial);
        foot.position.y = 0.08;
        foot.castShadow = true;
        bowlGroup.add(foot);


        surfaceMaterial = new THREE.RawShaderMaterial({
          vertexShader: surfaceVertexShader,
          fragmentShader: selectedSurfaceFragmentShader,
          glslVersion: THREE.GLSL3,
          uniforms: {
            uTime: { value: 0 },
            uWaves: { value: waveUniforms },
            uFogColor: { value: new THREE.Color("#210b28") },
            uFogDensity: { value: 0.034 },
          },
          side: THREE.DoubleSide,
          depthWrite: true,
          depthTest: true,
          transparent: false,
          toneMapped: false,
        });
        surface = new THREE.Mesh(makeSurfaceGeometry(segmentCount), surfaceMaterial);
        surface.rotation.x = -Math.PI / 2;
        surface.position.y = 0.765;
        surface.frustumCulled = false;
        bowlGroup.add(surface);

        const toppingDefinitions = [
          { count: 32, geometry: new THREE.SphereGeometry(0.135, 14, 12), material: new THREE.MeshPhysicalMaterial({ color: 0x3a114d, roughness: 0.22, metalness: 0.08, clearcoat: 0.84, clearcoatRoughness: 0.18, emissive: 0x15041d, emissiveIntensity: 0.2 }), scale: 0.88 },
          { count: 14, geometry: new THREE.TorusGeometry(0.145, 0.035, 8, 18), material: new THREE.MeshStandardMaterial({ color: 0xf1d17f, roughness: 0.36, metalness: 0.04, emissive: 0x51330f, emissiveIntensity: 0.1 }), scale: 1.0 },
          { count: 12, geometry: new THREE.ConeGeometry(0.14, 0.26, 8, 1), material: new THREE.MeshPhysicalMaterial({ color: 0xd94362, roughness: 0.28, clearcoat: 0.52, clearcoatRoughness: 0.24 }), scale: 0.88 },
          { count: 52, geometry: new THREE.DodecahedronGeometry(0.095, 0), material: new THREE.MeshStandardMaterial({ color: 0xc8964a, roughness: 0.74, metalness: 0.05 }), scale: 0.88 },
          { count: 10, geometry: new THREE.SphereGeometry(0.115, 10, 8), material: new THREE.MeshPhysicalMaterial({ color: 0xf1e1c5, roughness: 0.14, transmission: 0.22, thickness: 0.16, ior: 1.32, clearcoat: 0.9 }), scale: 1.12 },
          { count: 3, geometry: makeLeafShape(THREE), material: new THREE.MeshStandardMaterial({ color: 0x47794b, roughness: 0.55, side: THREE.DoubleSide, emissive: 0x112315, emissiveIntensity: 0.22 }), scale: 1.22 },
        ];
        const rawToppingCount = toppingDefinitions.reduce((sum, item) => sum + item.count, 0);
        const toppingScale = isMobile
          ? Math.min(1, MAX_MOBILE_TOPPINGS / rawToppingCount)
          : lowPowerDevice ? Math.min(0.62, MAX_MOBILE_TOPPINGS / rawToppingCount) : 1;
        for (const [batchIndex, definition] of toppingDefinitions.entries()) {
          const count = Math.max(1, Math.floor(definition.count * toppingScale));
          const mesh = new THREE.InstancedMesh(definition.geometry, definition.material, count);
          mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
          mesh.frustumCulled = false;
          bowlGroup.add(mesh);
          const specs: OrbitSpec[] = [];
          for (let index = 0; index < count; index++) {
            if (batchIndex === 3 && mesh.setColorAt) {
              mesh.setColorAt(index, new THREE.Color().setHSL(0.075 + Math.random() * 0.055, 0.34 + Math.random() * 0.22, 0.42 + Math.random() * 0.22));
            }
            specs.push({
              mesh,
              index,
              angle: Math.random() * Math.PI * 2,
              radius: 2.12 + Math.random() * 0.78,
              height: 0.94 + Math.random() * 1.18,
              speed: 0.12 + Math.random() * 0.22,
              tilt: (Math.random() * 2 - 1) * 0.82,
              scale: definition.scale * (0.68 + Math.random() * 0.66),
              boostUntil: 0,
              localPosition: new THREE.Vector3(),
            });
          }
          if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
          toppingBatches.push({ mesh, specs, activeCount: count, maxCount: count });
          orbiters.push(...specs);
        }
        toppingCount = toppingBatches.reduce((sum, batch) => sum + batch.activeCount, 0);

        const bubbleCount = isMobile || lowPowerDevice ? 14 : 22;
        const bubbleMaterial = new THREE.MeshPhysicalMaterial({ color: 0xf3e6cf, transparent: true, opacity: 0.32, roughness: 0.12, metalness: 0.08, transmission: 0.42, thickness: 0.12, ior: 1.31, depthWrite: false });
        bubbles = new THREE.InstancedMesh(new THREE.SphereGeometry(0.075, 10, 8), bubbleMaterial, bubbleCount);
        bubbles.frustumCulled = false;
        scene.add(bubbles);
        bubbleSpecs = Array.from({ length: bubbleCount }, (_, index) => ({
          index,
          x: (Math.random() - 0.5) * 8.0,
          y: -2.2 + Math.random() * 6.5,
          z: -1.4 + Math.random() * 2.4,
          speed: 0.12 + Math.random() * 0.22,
          scale: 0.45 + Math.random() * 0.76,
        }));

        const dustCount = isMobile ? 180 : lowPowerDevice ? 140 : 420;
        const positions = new Float32Array(dustCount * 3);
        const speeds = new Float32Array(dustCount);
        for (let index = 0; index < dustCount; index++) {
          positions[index * 3] = (Math.random() - 0.5) * 12;
          positions[index * 3 + 1] = -2.8 + Math.random() * 8.0;
          positions[index * 3 + 2] = -2.0 + Math.random() * 4.5;
          speeds[index] = 0.05 + Math.random() * 0.16;
        }
        dustPositions = positions;
        dustSpeeds = speeds;
        const dustGeometry = new THREE.BufferGeometry();
        dustGeometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
        const dustMaterial = new THREE.PointsMaterial({ color: 0xc8964a, size: isMobile ? 0.025 : 0.032, sizeAttenuation: true, transparent: true, opacity: 0.78, depthWrite: false, blending: THREE.AdditiveBlending });
        goldDust = new THREE.Points(dustGeometry, dustMaterial);
        scene.add(goldDust);

        const bubbleInstance = bubbles;
        const surfaceInstance = surface;
        const materialInstance = surfaceMaterial;
        const sceneInstance = scene;
        const cameraInstance = camera;
        const composerReady = async () => {
          if (isMobile || lowPowerDevice || !renderer) return;
          try {
            const [composerModule, renderPassModule, bloomModule, outputModule] = await Promise.all([
              runtimeImport("three/addons/postprocessing/EffectComposer.js"),
              runtimeImport("three/addons/postprocessing/RenderPass.js"),
              runtimeImport("three/addons/postprocessing/UnrealBloomPass.js"),
              runtimeImport("three/addons/postprocessing/OutputPass.js"),
            ]) as [ComposerModule, RenderPassModule, BloomModule, OutputPassModule];
            if (!alive || !renderer || !scene || !camera) return;
            composer = new composerModule.EffectComposer(renderer);
            composer.addPass(new renderPassModule.RenderPass(scene, camera));
            composer.addPass(new bloomModule.UnrealBloomPass(new THREE.Vector2(width, height), 0.46, 0.58, 0.82));
            composer.addPass(new outputModule.OutputPass());
            composer.setSize(width, height);
            debugStatus({ bloom: true });
          } catch {
            composer = null;
            debugStatus({ bloom: false, reason: "Bloom indisponível; renderer direto ativo." });
          }
        };
        await composerReady();
        if (!alive || !renderer || !scene || !camera) return;

        const frame = (now: number) => {
          if (!alive || !renderer || !scene || !camera || document.hidden) return;
          const dt = Math.min(0.05, Math.max(0, (now - previousFrame) / 1000));
          previousFrame = now;
          elapsed = (now - startTime) / 1000;
          if (!reducedMotion) updateScrollPose(pendingScrollY);
          if (surfaceMaterial) {
            surfaceMaterial.uniforms.uTime.value = elapsed;
            surfaceMaterial.uniforms.uWaves.value = waveUniforms;
          }
          if (bowlGroup) {
            if (!reducedMotion) {
              bowlGroup.rotation.y += dt * 0.14 + rotationVelocity * dt * 7;
              bowlGroup.position.y = Math.sin(elapsed * 0.58) * 0.065;
              rotationVelocity *= Math.exp(-dt * 2.3);
            }
          }
          for (const batch of toppingBatches) {
            for (let index = 0; index < batch.activeCount; index++) {
              const spec = batch.specs[index];
              const boosted = !reducedMotion && spec.boostUntil > elapsed;
              const speedMultiplier = boosted ? 3.8 : 1;
              if (!reducedMotion) spec.angle += dt * spec.speed * speedMultiplier;
              const x = Math.cos(spec.angle) * spec.radius;
              const z = Math.sin(spec.angle) * spec.radius * Math.cos(spec.tilt);
              const y = spec.height + Math.sin(spec.angle) * spec.radius * Math.sin(spec.tilt) * 0.72;
              spec.localPosition.set(x, y, z);
              dummy.position.copy(spec.localPosition);
              dummy.rotation.set(spec.tilt * 0.5 + Math.sin(spec.angle) * 0.12, spec.angle * (boosted ? 1.9 : 0.45) + spec.index, spec.tilt * 0.38);
              dummy.scale.setScalar(spec.scale * (boosted ? 1.13 : 1));
              dummy.updateMatrix();
              batch.mesh.setMatrixAt(index, dummy.matrix);
            }
            batch.mesh.count = batch.activeCount;
            batch.mesh.instanceMatrix.needsUpdate = true;
          }
          if (bubbles && bubbleInstance) {
            for (const bubble of bubbleSpecs) {
              if (!reducedMotion) {
                bubble.y += dt * bubble.speed;
                if (bubble.y > 4.8) bubble.y = -2.4;
              }
              dummy.position.set(bubble.x, bubble.y, bubble.z);
              dummy.scale.setScalar(bubble.scale);
              dummy.rotation.set(0, (reducedMotion ? 0 : elapsed * 0.1) + bubble.index, 0);
              dummy.updateMatrix();
              bubbles.setMatrixAt(bubble.index, dummy.matrix);
            }
            bubbles.instanceMatrix.needsUpdate = true;
          }
          if (goldDust && dustPositions && dustSpeeds && !reducedMotion) {
            for (let index = 0; index < dustSpeeds.length; index++) {
              const positionIndex = index * 3 + 1;
              dustPositions[positionIndex] += dt * dustSpeeds[index];
              if (dustPositions[positionIndex] > 4.8) dustPositions[positionIndex] = -2.6;
            }
            goldDust.geometry.attributes.position.needsUpdate = true;
            goldDust.rotation.y += dt * 0.012;
          }
          const liveWaveCount = waves.filter((wave) => elapsed - wave.start < WAVE_LIFE).length;
          if (composer) composer.render();
          else renderer.render(scene, camera);
          if (!frameCaptured) {
            frameCaptured = true;
            try {
              setFrameSnapshot(canvas.toDataURL("image/png"));
            } catch { /* o fallback SVG continua disponível se o navegador bloquear a captura */ }
          }
          frameCount++;
          if (!reducedMotion && now - fpsWindowStart >= 1000) {
            const fps = Math.round((frameCount * 1000) / (now - fpsWindowStart));
            fpsAverage = fpsAverage * 0.55 + fps * 0.45;
            if (fpsAverage < 40) lowFpsWindows++;
            else lowFpsWindows = 0;
            if (fpsAverage < 24 && adaptiveStage >= 2) lowFpsWindows = 2;
            debugStatus({
              fps: Math.round(fpsAverage),
              reason: `draw ${renderer?.info.render.calls ?? 0} · tris ${renderer?.info.render.triangles ?? 0} · cam ${camera?.position.x.toFixed(1)},${camera?.position.y.toFixed(1)},${camera?.position.z.toFixed(1)}`,
            });
            frameCount = 0;
            fpsWindowStart = now;
            if (lowFpsWindows >= 2 && adaptiveStage < 3) {
              adaptiveStage += 1;
              adaptive = true;
              segmentCount = adaptiveStage === 1
                ? (isMobile ? 72 : 112)
                : adaptiveStage === 2
                  ? (isMobile ? 56 : 80)
                  : (isMobile ? 40 : 56);
              if (surface) {
                surface.geometry.dispose();
                surface.geometry = makeSurfaceGeometry(segmentCount);
              }
              for (const batch of toppingBatches) {
                const fraction = adaptiveStage === 1 ? 0.62 : adaptiveStage === 2 ? 0.35 : 0.18;
                batch.activeCount = Math.max(2, Math.floor(batch.maxCount * fraction));
                batch.mesh.count = batch.activeCount;
              }
              if (adaptiveStage === 1 && composer) {
                composer.dispose();
                composer = null;
              }
              if (goldDust && dustSpeeds) {
                const dustFraction = adaptiveStage === 1 ? 0.5 : adaptiveStage === 2 ? 0.25 : 0.12;
                goldDust.geometry.setDrawRange(0, Math.max(12, Math.floor(dustSpeeds.length * dustFraction)));
              }
              const ratioCap = adaptiveStage === 3 ? 0.58 : adaptiveStage === 2 ? 0.85 : 1;
              renderer?.setPixelRatio(Math.min(window.devicePixelRatio || 1, ratioCap));
              renderer?.setSize(width, height, false);
              toppingCount = toppingBatches.reduce((sum, batch) => sum + batch.activeCount, 0);
              debugStatus({ adaptive: true, segments: segmentCount, toppings: toppingCount, bloom: Boolean(composer), reason: `Qualidade adaptativa nível ${adaptiveStage} por FPS abaixo de 40.` });
              lowFpsWindows = 0;
            }
          }
          const hasBoost = orbiters.some((spec) => !reducedMotion && spec.boostUntil > elapsed);
          const active = !reducedMotion || liveWaveCount > 0 || cameraMoving || hasBoost || Math.abs(rotationVelocity) > 0.002;
          if (!active) stopRenderer();
        };
        renderFrame = frame;

        onContextLost = (event) => {
          event.preventDefault();
          setFallback(new Error("Contexto WebGL2 perdido durante a renderização."));
        };
        onMotionPreferenceChange = (event) => {
          reducedMotion = event.matches;
          if (reducedMotion) {
            if (scrollFrame) {
              window.cancelAnimationFrame(scrollFrame);
              scrollFrame = 0;
            }
            pendingScrollY = window.scrollY;
            previousScrollY = pendingScrollY;
            lastScrollTime = performance.now();
            rotationVelocity = 0;
            cameraMoving = false;
            orbiters.forEach((spec) => { spec.boostUntil = 0; });
          } else {
            pendingScrollY = window.scrollY;
            previousScrollY = pendingScrollY;
            lastScrollTime = performance.now();
            updateScrollPose(pendingScrollY);
          }
          startRenderer();
        };
        onVisibilityChange = () => {
          if (document.hidden) {
            if (hiddenAt === null) hiddenAt = performance.now();
            stopRenderer();
            return;
          }
          if (hiddenAt !== null) {
            startTime += performance.now() - hiddenAt;
            hiddenAt = null;
            lowFpsWindows = 0;
          }
          startRenderer();
        };
        onResize = () => {
          if (!renderer || !camera) return;
          width = Math.max(1, window.innerWidth);
          height = Math.max(1, window.innerHeight);
          camera.aspect = width / height;
          camera.updateProjectionMatrix();
          const ratioCap = adaptiveStage === 3 ? 0.58 : adaptiveStage === 2 ? 0.85 : (lowPowerDevice || adaptiveStage === 1 ? 1 : 1.5);
          renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, ratioCap));
          renderer.setSize(width, height, false);
          composer?.setSize(width, height);
          startRenderer();
        };

        debugStatus({ webgl: "ok", fps: 0, bloom: Boolean(composer), toppings: toppingCount, segments: segmentCount, adaptive, reason: adaptive ? "Perfil inicial de baixo consumo ativo." : "" });
        setMode("webgl");
        previousScrollY = window.scrollY;
        pendingScrollY = previousScrollY;
        updateScrollPose(previousScrollY, false);
        renderer.compile(sceneInstance, cameraInstance);
        canvas.addEventListener("webglcontextlost", onContextLost);
        window.addEventListener("resize", onResize, { passive: true });
        window.addEventListener("scroll", onScroll, { passive: true });
        window.addEventListener("pointerdown", onPointerDown, { passive: true });
        window.addEventListener("pointermove", onPointerMove, { passive: true });
        window.addEventListener("pointerup", onPointerUp, { passive: true });
        window.addEventListener("pointercancel", onPointerUp, { passive: true });
        if (typeof window.PointerEvent === "undefined") {
          window.addEventListener("touchstart", onTouchStart, { passive: true });
          window.addEventListener("touchmove", onTouchMove, { passive: true });
          window.addEventListener("touchend", onTouchEnd, { passive: true });
          window.addEventListener("touchcancel", onTouchEnd, { passive: true });
        }
        window.addEventListener("mare-roxa:wave", onSplashWave);
        window.addEventListener("mare-roxa:reveal-center", onRevealCenter);
        document.addEventListener("visibilitychange", onVisibilityChange);
        motionQuery?.addEventListener("change", onMotionPreferenceChange);
        if ("ResizeObserver" in window) {
          resizeObserver = new ResizeObserver(onResize);
          resizeObserver.observe(document.documentElement);
        }
        if (!document.hidden) startRenderer();
      } catch (error) {
        if (alive) setFallback(error);
      }
    };

    void init();
    return () => {
      alive = false;
      runtimeCleanup();
    };
  }, []);

  const fallbackToppings = ["✦", "●", "◒", "♦", "✧", "●", "◖", "✦", "♦", "◒", "✧", "●"];
  const fallbackStyle = (index: number) => ({
    "--orbit-delay": `${-index * 0.67}s`,
    "--orbit-angle": `${index * 31}deg`,
    "--orbit-duration": `${11 + (index % 5) * 2.6}s`,
  }) as CSSProperties;

  const scene = (
    <div className={`surreal-scene surreal-scene-${mode}`} aria-hidden="true">
      {frameSnapshot && <img className="surreal-snapshot" src={frameSnapshot} alt="" aria-hidden="true" />}
      <canvas ref={canvasRef} className={`surreal-canvas ${mode === "webgl" ? "is-ready" : ""}`} />
      <div className={`surreal-fallback ${mode === "webgl" ? "surreal-fallback-underlay" : ""} ${frameSnapshot ? "has-snapshot" : ""}`}>
          <div className="surreal-fallback-orbit orbit-one"><i /></div>
          <div className="surreal-fallback-orbit orbit-two"><i /></div>
          <div className="surreal-fallback-orbit orbit-three"><i /></div>
          {fallbackToppings.map((item, index) => (
            <span className={`surreal-fallback-topping topping-${index % 5}`} key={`${item}-${index}`} style={fallbackStyle(index)}>{item}</span>
          ))}
          <div className="surreal-fallback-bowl">
            <svg className="surreal-bowl-svg" viewBox="0 0 900 650" role="presentation">
              <defs>
                <linearGradient id="fallback-wood" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0" stopColor="#2e130f" />
                  <stop offset=".32" stopColor="#774128" />
                  <stop offset=".62" stopColor="#3f1d17" />
                  <stop offset="1" stopColor="#8a4a29" />
                </linearGradient>
                <radialGradient id="fallback-acai" cx="42%" cy="30%" r="78%">
                  <stop offset="0" stopColor="#6b1e5c" />
                  <stop offset=".56" stopColor="#4b1248" />
                  <stop offset="1" stopColor="#2a0a2e" />
                </radialGradient>
                <linearGradient id="fallback-cream" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0" stopColor="#f3e6cf" stopOpacity="0" />
                  <stop offset=".46" stopColor="#f3e6cf" />
                  <stop offset="1" stopColor="#f3e6cf" stopOpacity="0" />
                </linearGradient>
                <filter id="fallback-shadow" x="-30%" y="-30%" width="160%" height="180%">
                  <feGaussianBlur stdDeviation="21" />
                </filter>
              </defs>
              <ellipse cx="451" cy="525" rx="291" ry="39" fill="#08020d" opacity=".55" filter="url(#fallback-shadow)" />
              <path d="M154 241 C178 371 301 492 450 506 C603 493 720 371 746 241 L683 240 C659 327 577 399 450 410 C321 399 241 327 216 240 Z" fill="url(#fallback-wood)" stroke="#bc7746" strokeOpacity=".64" strokeWidth="9" />
              <path d="M181 244 C253 170 652 170 719 244 C678 315 584 349 450 353 C316 349 223 315 181 244 Z" fill="url(#fallback-acai)" stroke="#d19a5a" strokeWidth="11" />
              <path d="M254 243 C331 214 393 221 442 244 C487 266 532 268 604 231" fill="none" stroke="url(#fallback-cream)" strokeWidth="12" strokeLinecap="round" opacity=".87" />
              <path d="M302 282 C369 305 435 300 492 274" fill="none" stroke="#f3e6cf" strokeWidth="4" strokeLinecap="round" opacity=".52" />
              <path d="M254 243 C278 323 356 376 449 387 C545 377 623 323 646 243" fill="none" stroke="#efc786" strokeWidth="3" strokeOpacity=".42" />
              <g fill="#c8964a">
                <circle cx="345" cy="230" r="7" /><circle cx="389" cy="253" r="5" /><circle cx="488" cy="224" r="6" />
                <circle cx="552" cy="251" r="7" /><circle cx="432" cy="285" r="5" /><circle cx="595" cy="274" r="4" />
              </g>
              <g fill="#f1d17f" opacity=".93">
                <ellipse cx="304" cy="255" rx="24" ry="10" transform="rotate(24 304 255)" />
                <ellipse cx="528" cy="236" rx="22" ry="9" transform="rotate(-22 528 236)" />
              </g>
              <g fill="#d94362">
                <path d="M451 214 C430 232 434 256 454 265 C475 255 476 231 451 214 Z" />
                <path d="M625 238 C607 252 611 272 629 280 C649 270 649 250 625 238 Z" />
              </g>
              <path d="M445 210 Q450 196 459 208 M621 236 Q625 225 635 233" fill="none" stroke="#6f9c5a" strokeWidth="5" strokeLinecap="round" />
              <path d="M192 257 C282 325 620 334 710 256" fill="none" stroke="#f0bd75" strokeOpacity=".24" strokeWidth="4" />
            </svg>
          </div>
          <div className="surreal-fallback-haze" />
      </div>
    </div>
  );
  const debug = debugEnabled && typeof document !== "undefined" ? createPortal(
    <aside className="surreal-debug" aria-live="polite">
      <strong>WebGL2: {diagnostics.webgl}</strong>
      <span>FPS: {diagnostics.fps || "—"}</span>
      <span>Bloom: {diagnostics.bloom ? "desktop" : "desativado"}</span>
      <span>Top.: {diagnostics.toppings} · malha: {diagnostics.segments}</span>
      {diagnostics.adaptive && <span>Qualidade adaptativa ativa</span>}
      {diagnostics.reason && <small title={diagnostics.reason}>{diagnostics.reason}</small>}
    </aside>,
    document.body,
  ) : null;

  return <>{scene}{debug}</>;
}

import { useId } from "react";
import type { ProductId } from "@/types/menu";

type ProductCupIllustrationProps = {
  productId: ProductId;
  className?: string;
  title?: string;
};

const recipes: Record<ProductId, { acai: string; cream: string; fruit: string; grain: string }> = {
  classico: { acai: "#64205b", cream: "#f3e6cf", fruit: "#e3bc59", grain: "#c8964a" },
  casadinho: { acai: "#612052", cream: "#e9c99d", fruit: "#f1e1ca", grain: "#d9a95a" },
  cacau: { acai: "#4a163d", cream: "#c8964a", fruit: "#f0d19b", grain: "#5b2a38" },
  jucara: { acai: "#51234f", cream: "#e8d0a3", fruit: "#bc7447", grain: "#d1aa5d" },
};

export default function ProductCupIllustration({ productId, className = "", title }: ProductCupIllustrationProps) {
  const recipe = recipes[productId];
  const instanceId = useId().replace(/[^a-zA-Z0-9_-]/g, "");
  const gradientId = `cup-${productId}-${instanceId}-glass`;
  const clipId = `cup-${productId}-${instanceId}-inside`;
  const açaíTop = productId === "casadinho" ? "#712262" : recipe.acai;

  return (
    <svg className={`product-cup-art ${className}`} viewBox="0 0 220 260" role={title ? "img" : undefined} aria-label={title} aria-hidden={title ? undefined : true}>
      <defs>
        <linearGradient id={gradientId} x1="0" x2="1" y1="0" y2="0.7">
          <stop offset="0" stopColor="#fff7e7" stopOpacity="0.52" />
          <stop offset="0.27" stopColor="#ffffff" stopOpacity="0.08" />
          <stop offset="0.72" stopColor="#fff7e7" stopOpacity="0.04" />
          <stop offset="1" stopColor="#e8d2b0" stopOpacity="0.42" />
        </linearGradient>
        <clipPath id={clipId}>
          <path d="M66 56h88l-14 150q-30 16-60 0L66 56Z" />
        </clipPath>
      </defs>
      <ellipse cx="110" cy="226" rx="55" ry="10" fill="#130718" opacity="0.28" />
      <g clipPath={`url(#${clipId})`}>
        <path d="M62 143q48-11 96 0l-11 67H73l-11-67Z" fill={recipe.acai} />
        <path d={productId === "casadinho" ? "M61 135q48 16 98-1v22q-47 15-95 0Z" : "M61 150q48-16 98 0v16q-47-12-95 1Z"} fill={recipe.cream} />
        {productId === "cacau" && <path d="M63 112q47-13 94 1v17q-48-12-94 2Z" fill="#35202b" />}
        {productId === "jucara" && <path d="M62 163q46 11 96-2v11q-46 16-94 1Z" fill="#d7b974" />}
        <path d="M63 118q47-18 94 0v26q-47-15-94 2Z" fill={açaíTop} />
        {productId === "classico" && <g fill={recipe.fruit} opacity="0.96"><ellipse cx="93" cy="135" rx="10" ry="5" transform="rotate(24 93 135)" /><ellipse cx="124" cy="131" rx="11" ry="5" transform="rotate(-18 124 131)" /><ellipse cx="109" cy="140" rx="10" ry="4" transform="rotate(8 109 140)" /></g>}
        {productId === "casadinho" && <path d="M106 54h54v83q-24 13-54 7Z" fill={recipe.cream} opacity="0.8" />}
        {productId === "cacau" && <g fill="#3b172d"><circle cx="88" cy="122" r="4" /><circle cx="117" cy="129" r="3.4" /><circle cx="136" cy="120" r="4.2" /><circle cx="103" cy="139" r="3" /></g>}
        {productId === "jucara" && <g fill={recipe.grain}><rect x="80" y="130" width="9" height="5" rx="1" transform="rotate(22 80 130)" /><rect x="116" y="137" width="10" height="4" rx="1" transform="rotate(-17 116 137)" /><rect x="133" y="128" width="8" height="5" rx="1" transform="rotate(12 133 128)" /></g>}
        {productId !== "cacau" && <g fill={recipe.grain} opacity="0.96"><rect x="82" y="112" width="7" height="5" rx="1" transform="rotate(18 82 112)" /><rect x="99" y="106" width="8" height="5" rx="1" transform="rotate(-12 99 106)" /><rect x="119" y="113" width="7" height="5" rx="1" transform="rotate(29 119 113)" /><rect x="135" y="105" width="6" height="5" rx="1" transform="rotate(-20 135 105)" /></g>}
        <path d="M70 57h78v47q-38-10-74 3Z" fill={recipe.cream} opacity="0.88" />
        {productId !== "jucara" && <g fill="#a52d4d"><path d="M92 58c-8-11 7-21 13-8 7-13 21-3 13 8l-13 13Z" /><path d="M119 54c-6-9 5-17 10-7 6-10 16-2 10 7l-10 11Z" /></g>}
        {productId === "jucara" && <g fill="#d8b965"><circle cx="88" cy="72" r="5" /><circle cx="109" cy="81" r="4" /><circle cx="135" cy="68" r="5" /><circle cx="124" cy="90" r="3" /></g>}
      </g>
      <path d="M66 56h88l-14 150q-30 16-60 0L66 56Z" fill={`url(#${gradientId})`} stroke="#f7edda" strokeOpacity="0.77" strokeWidth="2.2" />
      <ellipse cx="110" cy="56" rx="44" ry="9" fill="#fff4df" fillOpacity="0.2" stroke="#fff4df" strokeOpacity="0.82" strokeWidth="2" />
      <path d="M71 72q7 83 12 118" fill="none" stroke="#fff9ed" strokeOpacity="0.43" strokeWidth="4" strokeLinecap="round" />
      <path d="M80 214q29 13 60 0" fill="none" stroke="#fff4df" strokeOpacity="0.72" strokeWidth="2" />
      <path d="M153 56h12l-13 151q-5 5-10 5Z" fill="#fff4df" fillOpacity="0.09" />
    </svg>
  );
}

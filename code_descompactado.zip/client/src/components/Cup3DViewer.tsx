import { useEffect, useRef, useState } from "react";
import type * as THREE from "three";
import type { OrbitControls } from "three/addons/controls/OrbitControls.js";
import ProductCupIllustration from "@/components/ProductCupIllustration";
import type { ProductId } from "@/types/menu";

type Cup3DViewerProps = { productId: ProductId; productName: string };
type RuntimeImport = (specifier: string) => Promise<unknown>;
const runtimeImport = new Function("specifier", "return import(specifier)") as RuntimeImport;

function makeNoisyTexture(three: typeof THREE) {
  const canvas = document.createElement("canvas");
  canvas.width = 160;
  canvas.height = 160;
  const context = canvas.getContext("2d");
  if (context) {
    const image = context.createImageData(canvas.width, canvas.height);
    for (let y = 0; y < canvas.height; y++) {
      for (let x = 0; x < canvas.width; x++) {
        const wave = Math.sin(x * 0.12 + Math.sin(y * 0.07) * 4) * Math.cos(y * 0.13 + x * 0.015);
        const speckle = Math.random() * 0.28;
        const value = Math.max(0, Math.min(255, 105 + wave * 28 + speckle * 88));
        const offset = (y * canvas.width + x) * 4;
        image.data[offset] = value;
        image.data[offset + 1] = Math.max(0, value * 0.57);
        image.data[offset + 2] = Math.max(0, value * 0.92);
        image.data[offset + 3] = 255;
      }
    }
    context.putImageData(image, 0, 0);
  }
  const texture = new three.CanvasTexture(canvas);
  texture.colorSpace = three.SRGBColorSpace;
  texture.wrapS = three.RepeatWrapping;
  texture.wrapT = three.RepeatWrapping;
  texture.repeat.set(2, 1);
  return texture;
}

export default function Cup3DViewer({ productId, productName }: Cup3DViewerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const [fallback, setFallback] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const canvas = canvasRef.current;
    const stage = stageRef.current;
    if (!canvas || !stage) return;
    let alive = true;
    let frame = 0;
    let renderer: THREE.WebGLRenderer | null = null;
    let controls: OrbitControls | null = null;
    let scene: THREE.Scene | null = null;
    let camera: THREE.PerspectiveCamera | null = null;
    let cup: THREE.Group | null = null;
    let observer: ResizeObserver | null = null;
    let reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    let reduced = reducedMotion.matches;
    let interacting = false;
    let lastInput = performance.now();
    let previousFrame = performance.now();
    let noisyTexture: THREE.CanvasTexture | null = null;
    let visibilityHandler: (() => void) | null = null;
    let motionHandler: ((event: MediaQueryListEvent) => void) | null = null;

    const resize = () => {
      if (!renderer || !camera || !stage) return;
      const bounds = stage.getBoundingClientRect();
      if (!bounds.width || !bounds.height) return;
      renderer.setSize(bounds.width, bounds.height, false);
      camera.aspect = bounds.width / bounds.height;
      camera.updateProjectionMatrix();
    };

    const cleanupResources = () => {
      cancelAnimationFrame(frame);
      frame = 0;
      if (visibilityHandler) document.removeEventListener("visibilitychange", visibilityHandler);
      if (motionHandler) reducedMotion.removeEventListener("change", motionHandler);
      visibilityHandler = null;
      motionHandler = null;
      controls?.dispose();
      controls = null;
      observer?.disconnect();
      observer = null;
      if (renderer) renderer.dispose();
      renderer = null;
      noisyTexture?.dispose();
      noisyTexture = null;
      scene?.traverse((object) => {
        const mesh = object as THREE.Mesh;
        if (mesh.geometry) mesh.geometry.dispose();
        if (Array.isArray(mesh.material)) mesh.material.forEach((material) => material.dispose());
        else if (mesh.material) mesh.material.dispose();
      });
      scene = null;
      camera = null;
      cup = null;
    };

    const init = async () => {
      try {
        const three = await runtimeImport("three") as typeof THREE;
        const controlsModule = await runtimeImport("three/addons/controls/OrbitControls.js") as { OrbitControls: typeof OrbitControls };
        if (!alive) return;

        renderer = new three.WebGLRenderer({ canvas, alpha: true, antialias: true, powerPreference: "high-performance" });
        renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
        renderer.outputColorSpace = three.SRGBColorSpace;
        renderer.toneMapping = three.ACESFilmicToneMapping;
        renderer.setClearColor(0x000000, 0);

        scene = new three.Scene();
        camera = new three.PerspectiveCamera(32, 1, 0.1, 50);
        camera.position.set(0, 1.05, 6.2);
        scene.add(new three.AmbientLight(0xffe8d0, 1.7));
        const keyLight = new three.DirectionalLight(0xfff0d3, 3.3);
        keyLight.position.set(-3.5, 5, 4);
        scene.add(keyLight);
        const pinkLight = new three.DirectionalLight(0xe989c2, 2.7);
        pinkLight.position.set(3.6, 2.8, -2.5);
        scene.add(pinkLight);
        const goldLight = new three.PointLight(0xffcb75, 1.1, 8);
        goldLight.position.set(-2.3, 0.7, 2.2);
        scene.add(goldLight);

        cup = new three.Group();
        scene.add(cup);
        const colors: Record<ProductId, { acai: number; cream: number; base: number; fruit: number }> = {
          classico: { acai: 0x64205b, cream: 0xf0dfc4, base: 0xc8964a, fruit: 0xdcb846 },
          casadinho: { acai: 0x65204f, cream: 0xe4c296, base: 0xc8964a, fruit: 0xf2e2c9 },
          cacau: { acai: 0x491638, cream: 0xc8964a, base: 0x75412e, fruit: 0x5a2937 },
          jucara: { acai: 0x51234f, cream: 0xd8b974, base: 0xc8964a, fruit: 0xb96f43 },
        };
        const flavor = colors[productId];
        const acaiMaterial = new three.MeshStandardMaterial({ color: flavor.acai, roughness: 0.32 });
        const creamMaterial = new three.MeshStandardMaterial({ color: flavor.cream, roughness: 0.68 });
        const baseMaterial = new three.MeshStandardMaterial({ color: flavor.base, roughness: 0.65 });
        const addLayer = (radiusTop: number, radiusBottom: number, height: number, y: number, material: THREE.Material) => {
          const mesh = new three.Mesh(new three.CylinderGeometry(radiusTop, radiusBottom, height, 64, 1), material);
          mesh.position.y = y;
          cup?.add(mesh);
        };
        addLayer(0.37, 0.44, 1.13, 0.74, acaiMaterial);
        addLayer(0.41, 0.38, 0.31, 1.47, productId === "casadinho" ? acaiMaterial : creamMaterial);
        if (productId === "jucara") addLayer(0.4, 0.4, 0.14, 1.68, baseMaterial);
        if (productId === "cacau") addLayer(0.36, 0.37, 0.12, 1.65, baseMaterial);
        addLayer(0.36, 0.36, 0.19, 1.72, acaiMaterial);

        noisyTexture = makeNoisyTexture(three);
        const acaiTop = new three.Mesh(new three.SphereGeometry(0.405, 48, 32), new three.MeshStandardMaterial({ color: flavor.acai, map: noisyTexture, roughness: 0.29 }));
        acaiTop.scale.y = 0.31;
        acaiTop.position.y = 1.86;
        cup.add(acaiTop);

        const granolaMaterial = new three.MeshStandardMaterial({ color: flavor.base, roughness: 0.86 });
        const granola = new three.InstancedMesh(new three.BoxGeometry(0.075, 0.055, 0.072), granolaMaterial, 18);
        const granolaSeed = new three.Object3D();
        for (let i = 0; i < 18; i++) {
          const angle = i * 2.399;
          const radius = 0.08 + ((i * 37) % 11) / 48;
          granolaSeed.position.set(Math.cos(angle) * radius, 1.96 + Math.sin(angle * 2) * 0.018, Math.sin(angle) * radius);
          granolaSeed.rotation.set(angle * 0.6, angle, angle * 0.3);
          granolaSeed.scale.set(0.72 + (i % 4) * 0.13, 0.78 + (i % 3) * 0.12, 0.78 + (i % 5) * 0.08);
          granolaSeed.updateMatrix();
          granola.setMatrixAt(i, granolaSeed.matrix);
        }
        granola.instanceMatrix.needsUpdate = true;
        cup.add(granola);

        const bananaMaterial = new three.MeshStandardMaterial({ color: 0xf1d28a, roughness: 0.56 });
        const bananas = new three.InstancedMesh(new three.TorusGeometry(0.073, 0.019, 8, 18), bananaMaterial, 5);
        const bananaSeed = new three.Object3D();
        for (let i = 0; i < 5; i++) {
          const angle = (Math.PI * 2 * i) / 5;
          bananaSeed.position.set(Math.cos(angle) * 0.22, 1.98, Math.sin(angle) * 0.22);
          bananaSeed.rotation.set(Math.PI / 2, angle * 0.5, angle);
          bananaSeed.scale.set(0.78 + (i % 3) * 0.12, 0.78 + (i % 2) * 0.2, 1);
          bananaSeed.updateMatrix();
          bananas.setMatrixAt(i, bananaSeed.matrix);
        }
        bananas.instanceMatrix.needsUpdate = true;
        cup.add(bananas);

        if (productId !== "cacau") {
          const berryMaterial = new three.MeshStandardMaterial({ color: 0xb43855, roughness: 0.48 });
          const berries = new three.InstancedMesh(new three.ConeGeometry(0.072, 0.17, 8), berryMaterial, 3);
          const berrySeed = new three.Object3D();
          for (let i = 0; i < 3; i++) {
            const angle = (Math.PI * 2 * i) / 3 + 0.35;
            berrySeed.position.set(Math.cos(angle) * 0.27, 2.04, Math.sin(angle) * 0.27);
            berrySeed.rotation.set(0.2, angle, 0.18 + i * 0.12);
            berrySeed.updateMatrix();
            berries.setMatrixAt(i, berrySeed.matrix);
          }
          berries.instanceMatrix.needsUpdate = true;
          cup.add(berries);
        }

        const milkMaterial = new three.MeshPhysicalMaterial({ color: 0xfff5df, roughness: 0.22, metalness: 0.02 });
        const milkDrops = new three.InstancedMesh(new three.SphereGeometry(0.046, 16, 12), milkMaterial, 5);
        const dropSeed = new three.Object3D();
        for (let i = 0; i < 5; i++) {
          const angle = i * 2.1;
          dropSeed.position.set(Math.cos(angle) * (0.16 + (i % 2) * 0.08), 2.01 + (i % 3) * 0.014, Math.sin(angle) * (0.16 + (i % 2) * 0.08));
          dropSeed.scale.set(1.15, 0.7, 0.8);
          dropSeed.updateMatrix();
          milkDrops.setMatrixAt(i, dropSeed.matrix);
        }
        milkDrops.instanceMatrix.needsUpdate = true;
        cup.add(milkDrops);

        const glassMaterial = new three.MeshPhysicalMaterial({ color: 0xfff4df, transmission: 0.9, roughness: 0.05, ior: 1.45, thickness: 0.18, transparent: true, opacity: 0.26, side: three.DoubleSide });
        const profile = [new three.Vector2(0.34, 0.04), new three.Vector2(0.42, 0.08), new three.Vector2(0.56, 2.15), new three.Vector2(0.58, 2.2)];
        cup.add(new three.Mesh(new three.LatheGeometry(profile, 88), glassMaterial));
        const rim = new three.Mesh(new three.TorusGeometry(0.575, 0.018, 12, 72), new three.MeshPhysicalMaterial({ color: 0xfff2dc, transparent: true, opacity: 0.7, roughness: 0.14 }));
        rim.rotation.x = Math.PI / 2;
        rim.position.y = 2.19;
        cup.add(rim);
        cup.position.y = -1.03;

        controls = new controlsModule.OrbitControls(camera, renderer.domElement);
        controls.enableDamping = true;
        controls.dampingFactor = 0.065;
        controls.enablePan = false;
        controls.minDistance = 4.2;
        controls.maxDistance = 8.2;
        controls.target.set(0, 0.12, 0);
        controls.update();
        controls.addEventListener("start", () => { interacting = true; lastInput = performance.now(); });
        controls.addEventListener("end", () => { interacting = false; lastInput = performance.now(); });

        observer = new ResizeObserver(resize);
        observer.observe(stage);
        resize();
        setLoading(false);

        const render = (now: number) => {
          frame = 0;
          if (!alive || document.hidden || !renderer || !scene || !camera || !cup || !controls) return;
          const delta = Math.min(40, now - previousFrame);
          previousFrame = now;
          if (!reduced && !interacting && now - lastInput > 950) cup.rotation.y += delta * 0.00028;
          controls.update();
          renderer.render(scene, camera);
          frame = requestAnimationFrame(render);
        };
        const startRender = () => { if (!frame && alive && !document.hidden) { previousFrame = performance.now(); frame = requestAnimationFrame(render); } };
        const onVisibility = () => { if (document.hidden) { cancelAnimationFrame(frame); frame = 0; } else startRender(); };
        const onMotion = (event: MediaQueryListEvent) => { reduced = event.matches; };
        visibilityHandler = onVisibility;
        motionHandler = onMotion;
        document.addEventListener("visibilitychange", onVisibility);
        reducedMotion.addEventListener("change", onMotion);
        startRender();
        if (!alive) {
          cleanupResources();
        }
      } catch (error) {
        console.warn("Viewer 3D indisponível; usando ilustração SVG.", error);
        cleanupResources();
        if (alive) { setFallback(true); setLoading(false); }
      }
    };

    void init();
    return () => {
      alive = false;
      cleanupResources();
    };
  }, [productId]);

  return (
    <div className={`viewer-3d-stage${fallback ? " viewer-3d-fallback" : ""}`} ref={stageRef}>
      <canvas className="viewer-3d-canvas" ref={canvasRef} aria-label={`Modelo 3D de ${productName}`} hidden={fallback} />
      {fallback && <div className="viewer-svg-turntable" aria-label={`Ilustração em 3D de ${productName}`}><ProductCupIllustration productId={productId} title={`Copo de ${productName}`} /></div>}
      {loading && !fallback && <p className="viewer-loading" role="status">Preparando tua colherada 3D…</p>}
      <p className="viewer-hint" aria-hidden="true">Arraste para girar · Pinça ou roda para aproximar</p>
    </div>
  );
}

import { useState } from "react";
import type { FormEvent } from "react";
import { ArrowRight, Waves } from "lucide-react";

const NAME_PATTERN = /^[A-Za-zÀ-ÖØ-öø-ÿ' -]{2,40}$/;
const NAME_LETTERS = /[A-Za-zÀ-ÖØ-öø-ÿ]/g;

export function sanitizeNameInput(value: string) {
  return value.replace(/[^A-Za-zÀ-ÖØ-öø-ÿ' -]/g, "").slice(0, 40);
}

export function normalizeName(value: string) {
  const cleaned = sanitizeNameInput(value).trim().replace(/\s+/g, " ");
  return cleaned.toLocaleLowerCase("pt-BR").replace(/(^|[\s'-])([A-Za-zÀ-ÖØ-öø-ÿ])/g, (_match, separator: string, letter: string) => `${separator}${letter.toLocaleUpperCase("pt-BR")}`);
}

export function isValidName(value: string) {
  return NAME_PATTERN.test(value) && (value.match(NAME_LETTERS) ?? []).length >= 2;
}

function digitsOnly(value: string) {
  return value.replace(/\D/g, "").slice(0, 11);
}

function formatPhone(value: string) {
  const digits = digitsOnly(value);
  if (!digits) return "";
  if (digits.length <= 2) return `(${digits}`;
  const area = digits.slice(0, 2);
  const subscriber = digits.slice(2);
  const first = subscriber.slice(0, 1);
  const block = subscriber.slice(1, 5);
  const tail = subscriber.slice(5, 9);
  return `(${area}) ${first}${block ? ` ${block}` : ""}${tail ? `-${tail}` : ""}`;
}

function getNameError(value: string) {
  const normalized = normalizeName(value);
  if (!normalized) return "Digite seu nome.";
  if (!NAME_PATTERN.test(normalized)) return "Use apenas letras no nome.";
  if ((normalized.match(NAME_LETTERS) ?? []).length < 2) return "Informe ao menos duas letras no nome.";
  return "";
}

function getPhoneError(value: string) {
  const digits = digitsOnly(value);
  if (!digits) return "Digite seu WhatsApp.";
  if (digits.length !== 11) return "Informe os 11 dígitos do WhatsApp.";
  const areaCode = Number(digits.slice(0, 2));
  if (areaCode < 11 || areaCode > 99) return "Informe um DDD entre 11 e 99.";
  if (digits[2] !== "9") return "Após o DDD, o número deve começar com 9.";
  return "";
}

type SplashScreenProps = { onEnter: () => void };

export function SplashScreen({ onEnter }: SplashScreenProps) {
  return (
    <section className="splash-screen" aria-label="Entrada Maré Roxa">
      <div className="splash-content">
        <div className="splash-logo" aria-hidden="true"><Waves size={52} strokeWidth={1.25} /></div>
        <p className="splash-kicker">SÃO LUÍS · MARANHÃO</p>
        <h1>Maré Roxa <span>—</span><br /><em>Açaí & Juçara da Ilha</em></h1>
        <button className="splash-enter" type="button" onClick={onEnter}>toque para entrar <ArrowRight size={15} /></button>
      </div>
    </section>
  );
}

type DemoLoginCardProps = {
  initialName: string;
  isDissolving: boolean;
  onEnter: (name: string, phone: string) => void;
  onVisitor: () => void;
};

export function DemoLoginCard({ initialName, isDissolving, onEnter, onVisitor }: DemoLoginCardProps) {
  const [name, setName] = useState(initialName);
  const [phone, setPhone] = useState("");
  const [nameTouched, setNameTouched] = useState(false);
  const [phoneTouched, setPhoneTouched] = useState(false);

  const nameError = nameTouched ? getNameError(name) : "";
  const phoneError = phoneTouched ? getPhoneError(phone) : "";
  const formValid = isValidName(normalizeName(name)) && !getPhoneError(phone);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNameTouched(true);
    setPhoneTouched(true);
    const normalized = normalizeName(name);
    const digits = digitsOnly(phone);
    if (!isValidName(normalized) || getPhoneError(digits)) return;
    onEnter(normalized, digits);
  }

  return (
    <section className="login-screen" aria-label="Login demonstrativo">
      <form className={`demo-login-card card${isDissolving ? " is-dissolving" : ""}`} onSubmit={submit} noValidate>
        <div className="login-mark" aria-hidden="true"><Waves size={28} strokeWidth={1.5} /></div>
        <p className="eyebrow">A MARÉ TE ESPERA</p>
        <h1>Chega mais,<br /><em>fica à vontade.</em></h1>
        <p className="login-intro">Uma pausa com sabor de ilha começa com teu nome.</p>
        <div className="login-field">
          <label htmlFor="demo-name">Teu nome</label>
          <input
            id="demo-name"
            name="name"
            type="text"
            autoComplete="name"
            maxLength={40}
            required
            aria-required="true"
            aria-invalid={Boolean(nameError)}
            aria-describedby="demo-name-error"
            value={name}
            onChange={(event) => setName(sanitizeNameInput(event.currentTarget.value))}
            onBlur={() => { setName(normalizeName(name)); setNameTouched(true); }}
            placeholder="Como podemos te chamar?"
          />
          <span className="field-error" id="demo-name-error" aria-live="polite">{nameError}</span>
        </div>
        <div className="login-field">
          <label htmlFor="demo-phone">Telefone / WhatsApp</label>
          <input
            id="demo-phone"
            name="phone"
            type="tel"
            inputMode="numeric"
            autoComplete="tel"
            maxLength={16}
            required
            aria-required="true"
            aria-invalid={Boolean(phoneError)}
            aria-describedby="demo-phone-error"
            value={phone}
            onChange={(event) => setPhone(formatPhone(event.currentTarget.value))}
            onBlur={() => setPhoneTouched(true)}
            placeholder="(98) 9 9999-9999"
          />
          <span className="field-error" id="demo-phone-error" aria-live="polite">{phoneError}</span>
        </div>
        <button className="login-submit" type="submit" disabled={!formValid}>Entrar <ArrowRight size={16} /></button>
        <button className="login-google" type="button" aria-describedby="google-demo-note"><span className="google-g" aria-hidden="true">G</span>Continuar com Google</button>
        <span id="google-demo-note" className="visually-hidden">Botão apenas visual; nenhuma autenticação será iniciada.</span>
        <button className="login-visitor" type="button" onClick={onVisitor}>Entrar como visitante</button>
        <p className="login-disclaimer">Login demonstrativo — projeto fictício</p>
      </form>
    </section>
  );
}
